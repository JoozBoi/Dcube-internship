import React, { useState, useEffect } from 'react';
import { 
  Map, 
  Compass, 
  MessageSquare, 
  Shield, 
  Briefcase, 
  Plus, 
  CornerDownRight, 
  Trash2, 
  FileText, 
  CheckCircle, 
  X, 
  Users, 
  LogOut, 
  ChevronRight, 
  Clock, 
  DollarSign, 
  MapPin, 
  ArrowUp, 
  ArrowDown, 
  Check, 
  AlertTriangle, 
  Award,
  Send,
  Sliders,
  Settings,
  Star
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  // Authentication & Switching Roles state
  const [currentUser, setCurrentUser] = useState({
    uid: 'traveller-uid',
    username: 'SaraWanderer',
    email: 'sara@example.com',
    role: 'traveller',
    bio: 'Lover of mountain passes, remote temple hikes, and authentic experiences.'
  });

  const [usersList, setUsersList] = useState([]);
  const [posts, setPosts] = useState([]);
  const [packages, setPackages] = useState([]);
  const [verifications, setVerifications] = useState([]);
  const [flaggedPosts, setFlaggedPosts] = useState([]);
  const [commentReports, setCommentReports] = useState([]);
  const [auditLogs, setAuditLogs] = useState([]);

  // Active Tab/Filter states
  const [activeSegment, setActiveSegment] = useState('feed'); // feed | packages | agency | admin
  const [selectedPost, setSelectedPost] = useState(null);
  const [selectedPackage, setSelectedPackage] = useState(null);

  // Forms states
  const [showAddPostModal, setShowAddPostModal] = useState(false);
  const [showAddPkgModal, setShowAddPkgModal] = useState(false);
  const [showEditProfileModal, setShowEditProfileModal] = useState(false);

  // Add post inputs
  const [postTitle, setPostTitle] = useState('');
  const [postLoc, setPostLoc] = useState('');
  const [postDesc, setPostDesc] = useState('');
  const [postCost, setPostCost] = useState('');
  const [postDuration, setPostDuration] = useState('');
  const [postDifficulty, setPostDifficulty] = useState('Moderate');
  const [postDays, setPostDays] = useState([{ day: 1, title: '', description: '', badges: '' }]);

  // Add package inputs
  const [pkgTitle, setPkgTitle] = useState('');
  const [pkgDest, setPkgDest] = useState('');
  const [pkgDuration, setPkgDuration] = useState('');
  const [pkgPrice, setPkgPrice] = useState('1200');
  const [pkgDesc, setPkgDesc] = useState('');
  const [pkgInclusions, setPkgInclusions] = useState('');
  const [pkgStayName, setPkgStayName] = useState('');
  const [pkgStayDesc, setPkgStayDesc] = useState('');

  // Submit verification agency inputs
  const [agencyVerifyName, setAgencyVerifyName] = useState('');
  const [agencyVerifyEmail, setAgencyVerifyEmail] = useState('');
  const [agencyVerifyPhone, setAgencyVerifyPhone] = useState('');
  const [agencyFilesCount, setAgencyFilesCount] = useState('2');

  // Edit profile inputs
  const [profileUsername, setProfileUsername] = useState('');
  const [profileBio, setProfileBio] = useState('');
  const [profileEmail, setProfileEmail] = useState('');

  // New Comment texts (postId -> comment text)
  const [commentTexts, setCommentTexts] = useState({});
  const [replyInputBox, setReplyInputBox] = useState(null); // commentId for reply input

  // Global alerts/notifications
  const [alertMsg, setAlertMsg] = useState(null);

  // Fetch all initial data
  const headers = {
    'Content-Type': 'application/json',
    'x-user-role': currentUser.role,
    'x-user-username': currentUser.username
  };

  const loadData = async () => {
    try {
      const postsRes = await fetch('/api/posts', { headers });
      if (postsRes.ok) {
        const postsData = await postsRes.json();
        setPosts(postsData);
      }

      const pkgsRes = await fetch('/api/packages', { headers });
      if (pkgsRes.ok) {
        const pkgsData = await pkgsRes.json();
        setPackages(pkgsData);
      }

      const usersRes = await fetch('/api/users', { headers });
      if (usersRes.ok) {
        const uList = await usersRes.json();
        setUsersList(uList);
        // Find current user profile consistency
        const matched = uList.find(u => u.role === currentUser.role);
        if (matched) {
          setCurrentUser({
            uid: matched.uid,
            username: matched.username,
            email: matched.email,
            role: matched.role,
            bio: matched.bio
          });
        }
      }

      if (currentUser.role === 'admin') {
        const logsRes = await fetch('/api/admin/audit-logs', { headers });
        if (logsRes.ok) setAuditLogs(await logsRes.json());

        const fRes = await fetch('/api/flagged-posts', { headers });
        if (fRes.ok) setFlaggedPosts(await fRes.json());

        const cRes = await fetch('/api/comment-reports', { headers });
        if (cRes.ok) setCommentReports(await cRes.json());

        const vRes = await fetch('/api/verifications', { headers });
        if (vRes.ok) setVerifications(await vRes.json());
      }
    } catch (e) {
      console.error('Handshake fetching error:', e);
    }
  };

  useEffect(() => {
    loadData();
  }, [currentUser.role, currentUser.username]);

  // Temporary trigger alert
  const triggerAlert = (text) => {
    setAlertMsg(text);
    setTimeout(() => {
      setAlertMsg(null);
    }, 4000);
  };

  // Auth Switching
  const handleSwitchUserRole = (role) => {
    let username = 'SaraWanderer';
    let email = 'sara@example.com';
    let bio = 'Lover of mountain passes, remote temple hikes, and authentic experiences.';
    
    if (role === 'admin') {
      username = 'admin';
      email = 'admin@vazhikal.io';
      bio = 'Secure administrative intelligence node control center.';
      setActiveSegment('admin');
    } else if (role === 'agency') {
      username = 'EverestTrek';
      email = 'info@everesttrekkers.np';
      bio = 'Licensed Mountain Passes & Sherpa Trail specialists.';
      setActiveSegment('agency');
    } else {
      setActiveSegment('feed');
    }
    
    setCurrentUser({ uid: role + '_temp', username, email, role, bio });
    triggerAlert(`Switched view to ${role.toUpperCase()} Context Node: ${username}`);
  };

  // Edit profile submit
  const handleEditProfileSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch(`/api/users/${currentUser.email}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'x-user-role': currentUser.role,
          'x-user-username': currentUser.username
        },
        body: JSON.stringify({
          username: profileUsername || currentUser.username,
          bio: profileBio !== undefined ? profileBio : currentUser.bio,
          email: profileEmail || currentUser.email
        })
      });

      if (res.ok) {
        const updated = await res.json();
        setCurrentUser({
          ...currentUser,
          username: updated.user.username,
          bio: updated.user.bio,
          email: updated.user.email
        });
        setShowEditProfileModal(false);
        triggerAlert('Handshake Profile Coordinates synchronized successfully on PostgreSQL database');
        loadData();
      } else {
        triggerAlert('Error updating account credentials in core');
      }
    } catch (e) {
      console.error(e);
      triggerAlert('Networking failure on updating user');
    }
  };

  const openProfileEdit = () => {
    setProfileUsername(currentUser.username);
    setProfileBio(currentUser.bio || '');
    setProfileEmail(currentUser.email);
    setShowEditProfileModal(true);
  };

  // Submit Post
  const handleAddPostSubmit = async (e) => {
    e.preventDefault();
    try {
      const parsedDays = postDays.map(d => ({
        day: parseInt(d.day),
        title: d.title || 'Sightseeing & Route Exploring',
        description: d.description || 'General outdoor walking and exploration of the scenic trails.',
        badges: d.badges ? d.badges.split(',').map(b => b.trim()) : ['Trail']
      }));

      const payload = {
        title: postTitle,
        location: postLoc,
        description: postDesc,
        cost: postCost || '$50 USD',
        duration: postDuration || '1 Day',
        difficulty: postDifficulty,
        dayByDay: parsedDays,
        imageUrl: 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=800',
        imageAlt: 'Travel route guide trail visual shot'
      };

      const res = await fetch('/api/posts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-role': currentUser.role,
          'x-user-username': currentUser.username
        },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        setPostTitle('');
        setPostLoc('');
        setPostDesc('');
        setPostCost('');
        setPostDuration('');
        setPostDays([{ day: 1, title: '', description: '', badges: '' }]);
        setShowAddPostModal(false);
        triggerAlert('Experiential Itinerary Trail recorded permanently in PostgreSQL database');
        loadData();
      }
    } catch (err) {
      console.error(err);
      triggerAlert('Failed to save travel post');
    }
  };

  // Delete Post
  const handleDeletePost = async (id) => {
    if (!window.confirm('Delete this experiences post entirely? This removes all recursive nested discussion comments.')) return;
    try {
      const res = await fetch(`/api/posts/${id}`, {
        method: 'DELETE',
        headers: {
          'x-user-role': currentUser.role,
          'x-user-username': currentUser.username
        }
      });
      if (res.ok) {
        triggerAlert('Itinerary Trail and its comments deleted successfully');
        loadData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Upvote/Downvote
  const handlePostVote = async (id, amount) => {
    try {
      const res = await fetch(`/api/posts/${id}/vote`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-role': currentUser.role,
          'x-user-username': currentUser.username
        },
        body: JSON.stringify({ amount })
      });
      if (res.ok) {
        const data = await res.json();
        setPosts(posts.map(p => p.id === id ? { ...p, votes: data.votes } : p));
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Submit Comment / Reply
  const handleSubmitComment = async (e, postId, parentId = null) => {
    e.preventDefault();
    const txt = commentTexts[parentId ? `reply_${parentId}` : `post_${postId}`];
    if (!txt || !txt.trim()) return;

    try {
      const res = await fetch(`/api/posts/${postId}/comments`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-role': currentUser.role,
          'x-user-username': currentUser.username
        },
        body: JSON.stringify({
          text: txt,
          parentId: parentId
        })
      });

      if (res.ok) {
        setCommentTexts({
          ...commentTexts,
          [parentId ? `reply_${parentId}` : `post_${postId}`]: ''
        });
        setReplyInputBox(null);
        triggerAlert('Discussion comment inserted in nested chain');
        loadData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Delete Comment
  const handleDeleteComment = async (commentId) => {
    if (!window.confirm('Delete this comment and its nested children recursively?')) return;
    try {
      const res = await fetch(`/api/comments/${commentId}`, {
        method: 'DELETE',
        headers: {
          'x-user-role': currentUser.role,
          'x-user-username': currentUser.username
        }
      });
      if (res.ok) {
        triggerAlert('Comment branches deleted successfully from database');
        loadData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Submit Package
  const handleAddPkgSubmit = async (e) => {
    e.preventDefault();
    try {
      const payload = {
        title: pkgTitle,
        destination: pkgDest,
        duration: pkgDuration || '3 Days, 2 Nights',
        price: parseInt(pkgPrice) || 800,
        status: 'Active',
        description: pkgDesc,
        inclusions: pkgInclusions ? pkgInclusions.split(',').map(i => i.trim()) : [],
        stayNameText: pkgStayName || 'Traditional Boutique Residency',
        stayDescText: pkgStayDesc || 'Custom interior layouts with majestic mountain sunrise vistas.',
        stayRating: '4.9',
        stayReviewsCount: 12,
        stayValue: parseInt(pkgPrice) > 1500 ? 800 : 400,
        dayByDay: [
          { day: 1, title: 'Check-in and Welcome Spread', description: 'Arrive at selected luxury resort. Private concierge service greeting with fine organic bites and room views setup.', badges: ['VIP Welcome', 'Bespoke Diner'] }
        ]
      };

      const res = await fetch('/api/packages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-role': currentUser.role,
          'x-user-username': currentUser.username
        },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        setPkgTitle('');
        setPkgDest('');
        setPkgDuration('');
        setPkgDesc('');
        setPkgInclusions('');
        setPkgStayName('');
        setPkgStayDesc('');
        setShowAddPkgModal(false);
        triggerAlert('Curated agency travel tour package listed permanently');
        loadData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Delete Package
  const handleDeletePackage = async (id) => {
    if (!window.confirm('Delete this curated tour package permanently?')) return;
    try {
      const res = await fetch(`/api/packages/${id}`, {
        method: 'DELETE',
        headers: {
          'x-user-role': currentUser.role,
          'x-user-username': currentUser.username
        }
      });
      if (res.ok) {
        triggerAlert('Travel Package dissolved from repository database');
        loadData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Submit Verification Agent Application
  const handleAgencyApplyVerification = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/verifications', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-role': currentUser.role,
          'x-user-username': currentUser.username
        },
        body: JSON.stringify({
          companyName: agencyVerifyName || currentUser.username,
          email: agencyVerifyEmail || currentUser.email,
          phone: agencyVerifyPhone || '+977-1-98442',
          filesCount: parseInt(agencyFilesCount) || 2
        })
      });

      if (res.ok) {
        setAgencyVerifyName('');
        setAgencyVerifyEmail('');
        setAgencyVerifyPhone('');
        triggerAlert('✓ Agency Verification request submitted to Administration panel validation queue.');
        loadData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Approve Agency Verification
  const handleApproveAgency = async (vId) => {
    try {
      const res = await fetch(`/api/verifications/${vId}/approve`, {
        method: 'POST',
        headers: {
          'x-user-role': currentUser.role,
          'x-user-username': currentUser.username
        }
      });
      if (res.ok) {
        triggerAlert('Agency Verification application approved. System logged event.');
        loadData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Clean Mod flag / Spam resolution
  const handleResolveFlaggedPost = async (id) => {
    try {
      const res = await fetch(`/api/flagged-posts/${id}`, {
        method: 'DELETE',
        headers: {
          'x-user-role': currentUser.role,
          'x-user-username': currentUser.username
        }
      });
      if (res.ok) {
        triggerAlert('Moderator resolved flagged trail posts queue node.');
        loadData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Delete Reported Comments
  const handleResolveCommentReport = async (id) => {
    try {
      const res = await fetch(`/api/comment-reports/${id}`, {
        method: 'DELETE',
        headers: {
          'x-user-role': currentUser.role,
          'x-user-username': currentUser.username
        }
      });
      if (res.ok) {
        triggerAlert('Comment moderation flag resolved.');
        loadData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Recursive Comment JSX
  const renderCommentNode = (c, postId) => {
    return (
      <div key={c.id} className="mt-3 pl-3 border-l-2 border-neutral-200">
        <div className="flex items-start gap-2">
          <img 
            src={c.authorAvatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150"} 
            alt={c.author} 
            className="w-6 h-6 rounded-full object-cover"
          />
          <div className="flex-1 bg-neutral-50 px-3 py-2 rounded-lg text-xs">
            <div className="flex justify-between items-center mb-1">
              <span className="font-semibold text-neutral-800 flex items-center gap-1">
                {c.author}
                {c.isVerified && (
                  <span className="bg-emerald-100 text-emerald-800 text-[10px] scale-90 px-1 rounded font-normal">
                    Verified Agent
                  </span>
                )}
              </span>
              <span className="text-[10px] text-neutral-400">{c.timeAgo || 'Just now'}</span>
            </div>
            
            <p className="text-neutral-700 leading-relaxed font-sans">{c.text}</p>
            
            <div className="flex items-center gap-3 mt-2 text-[10px] text-neutral-500 font-medium">
              <button 
                onClick={() => setReplyInputBox(replyInputBox === c.id ? null : c.id)}
                className="hover:text-amber-600 transition flex items-center gap-1"
              >
                <CornerDownRight size={12} /> Reply
              </button>

              {(currentUser.role === 'admin' || currentUser.username === c.author) && (
                <button 
                  onClick={() => handleDeleteComment(c.id)}
                  className="text-red-500 hover:text-red-700 transition"
                >
                  Delete
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Nested replies input box */}
        {replyInputBox === c.id && (
          <form 
            onSubmit={(e) => handleSubmitComment(e, postId, c.id)}
            className="flex items-center gap-2 mt-2 ml-6"
          >
            <input 
              type="text"
              placeholder={`Reply to ${c.author}...`}
              value={commentTexts[`reply_${c.id}`] || ''}
              onChange={(e) => setCommentTexts({ ...commentTexts, [`reply_${c.id}`]: e.target.value })}
              className="flex-1 text-xs px-3 py-1.5 border border-neutral-300 rounded-md focus:outline-none focus:border-amber-500"
              required
            />
            <button 
              type="submit"
              className="bg-amber-600 text-white p-1.5 rounded-md hover:bg-amber-700 transition"
            >
              <Send size={12} />
            </button>
          </form>
        )}

        {/* Recursive list of child replies */}
        {c.replies && c.replies.map(reply => renderCommentNode(reply, postId))}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-neutral-100 flex flex-col font-sans">
      
      {/* Alert Notice banner */}
      <AnimatePresence>
        {alertMsg && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-4 left-1/2 -translate-x-1/2 z-50 bg-neutral-900 text-amber-400 text-xs px-4 py-2.5 rounded-lg shadow-xl flex items-center gap-2 border border-amber-500/20"
          >
            <CheckCircle size={14} className="text-amber-500" />
            <span className="font-mono">{alertMsg}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* TOP HEADER */}
      <header className="sticky top-0 z-40 bg-white border-b border-neutral-200 px-6 py-3 flex justify-between items-center shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-amber-600 rounded-xl flex items-center justify-center text-white font-mono font-bold text-lg tracking-tight shadow-md">
            V
          </div>
          <div>
            <h1 id="app-title" className="text-base font-semibold text-neutral-800 tracking-tight font-sans">Vazhikal Trails</h1>
            <p className="text-[10px] text-neutral-400 uppercase font-mono tracking-widest">PostgreSQL Marketplace</p>
          </div>
        </div>

        {/* User context switcher directly integrated into the header bar for seamless evaluation */}
        <div className="bg-neutral-50 border border-neutral-200 rounded-full py-1 px-4 flex items-center gap-4">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse"></div>
            <span className="text-[11px] text-neutral-500 font-mono">
              <span className="font-semibold text-neutral-800">Role:</span> {currentUser.role.toUpperCase()}
            </span>
          </div>

          <div className="h-4 w-[1px] bg-neutral-300"></div>

          <div className="flex gap-1.5">
            <button 
              onClick={() => handleSwitchUserRole('traveller')}
              className={`text-[10px] px-2.5 py-1 rounded-full text-xs font-medium cursor-pointer transition ${
                currentUser.role === 'traveller' 
                  ? 'bg-amber-600 text-white' 
                  : 'bg-neutral-200 text-neutral-700 hover:bg-neutral-300'
              }`}
            >
              Traveller
            </button>
            <button 
              onClick={() => handleSwitchUserRole('agency')}
              className={`text-[10px] px-2.5 py-1 rounded-full text-xs font-medium cursor-pointer transition ${
                currentUser.role === 'agency' 
                  ? 'bg-amber-600 text-white' 
                  : 'bg-neutral-200 text-neutral-700 hover:bg-neutral-300'
              }`}
            >
              Agency
            </button>
            <button 
              onClick={() => handleSwitchUserRole('admin')}
              className={`text-[10px] px-2.5 py-1 rounded-full text-xs font-medium cursor-pointer transition ${
                currentUser.role === 'admin' 
                  ? 'bg-amber-600 text-white' 
                  : 'bg-neutral-200 text-neutral-700 hover:bg-neutral-300'
              }`}
            >
              Admin View
            </button>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 cursor-pointer" onClick={openProfileEdit}>
            <div className="text-right">
              <p className="text-xs font-semibold text-neutral-800">{currentUser.username}</p>
              <p className="text-[10px] text-zinc-400">Settings</p>
            </div>
            <img 
              src={currentUser.role === 'admin' 
                ? "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150" 
                : "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150"
              } 
              alt="avatar" 
              className="w-8 h-8 rounded-full border border-amber-600/20 object-cover"
            />
          </div>
        </div>
      </header>

      {/* SEGMENT METRIC TILES */}
      <div className="max-w-7xl mx-auto w-full px-6 pt-6 grid grid-cols-2 sm:grid-cols-4 gap-4">
        
        <div 
          onClick={() => setActiveSegment('feed')}
          className={`cursor-pointer border p-4 rounded-xl transition ${
            activeSegment === 'feed' 
              ? 'bg-white border-amber-600 shadow-md ring-1 ring-amber-600/10' 
              : 'bg-white border-neutral-200 hover:border-neutral-300 shadow-xs'
          }`}
        >
          <div className="flex justify-between items-start">
            <Compass size={18} className={activeSegment === 'feed' ? 'text-amber-600' : 'text-neutral-400'} />
            <span className="text-[10px] font-mono font-semibold bg-neutral-100 text-neutral-600 px-1.5 py-0.5 rounded">
              {posts.length} Trails
            </span>
          </div>
          <p className="text-xs font-semibold text-neutral-800 mt-2">Trails Feed</p>
          <p className="text-[10px] text-neutral-400 mt-0.5">Experiential itineraries</p>
        </div>

        <div 
          onClick={() => setActiveSegment('packages')}
          className={`cursor-pointer border p-4 rounded-xl transition ${
            activeSegment === 'packages' 
              ? 'bg-white border-amber-600 shadow-md ring-1 ring-amber-600/10' 
              : 'bg-white border-neutral-200 hover:border-neutral-300 shadow-xs'
          }`}
        >
          <div className="flex justify-between items-start">
            <Briefcase size={18} className={activeSegment === 'packages' ? 'text-amber-600' : 'text-neutral-400'} />
            <span className="text-[10px] font-mono font-semibold bg-green-50 text-green-700 px-1.5 py-0.5 rounded">
              {packages.length} Active
            </span>
          </div>
          <p className="text-xs font-semibold text-neutral-800 mt-2">Tour Packages</p>
          <p className="text-[10px] text-neutral-400 mt-0.5">Curated listings & stays</p>
        </div>

        <div 
          onClick={() => setActiveSegment('agency')}
          className={`cursor-pointer border p-4 rounded-xl transition ${
            activeSegment === 'agency' 
              ? 'bg-white border-amber-600 shadow-md ring-1 ring-amber-600/10' 
              : 'bg-white border-neutral-200 hover:border-neutral-300 shadow-xs'
          }`}
        >
          <div className="flex justify-between items-start">
            <Award size={18} className={activeSegment === 'agency' ? 'text-amber-600' : 'text-neutral-400'} />
            <span className="text-[10px] font-mono font-semibold bg-blue-50 text-blue-700 px-1.5 py-0.5 rounded">
              Verify Console
            </span>
          </div>
          <p className="text-xs font-semibold text-neutral-800 mt-2">Agency Desk</p>
          <p className="text-[10px] text-neutral-400 mt-0.5">Submit verification request</p>
        </div>

        <div 
          onClick={() => {
            if (currentUser.role !== 'admin') {
              triggerAlert('🔑 Admin role required to toggle administrative moderation segments.');
              return;
            }
            setActiveSegment('admin');
          }}
          className={`cursor-pointer border p-4 rounded-xl transition ${
            currentUser.role !== 'admin' ? 'opacity-65' : ''
          } ${
            activeSegment === 'admin' 
              ? 'bg-white border-amber-600 shadow-md ring-1 ring-amber-600/10' 
              : 'bg-white border-neutral-200 hover:border-neutral-300 shadow-xs'
          }`}
        >
          <div className="flex justify-between items-start">
            <Shield size={18} className={activeSegment === 'admin' ? 'text-amber-600' : 'text-neutral-400'} />
            <span className="text-[10px] font-mono font-semibold bg-red-50 text-red-700 px-1.5 py-0.5 rounded">
              {currentUser.role === 'admin' ? 'Active logs' : 'Locked'}
            </span>
          </div>
          <p className="text-xs font-semibold text-neutral-800 mt-2">Moderation & Audits</p>
          <p className="text-[10px] text-neutral-400 mt-0.5">Spam logs, reported items</p>
        </div>

      </div>

      {/* DASHBOARD CONTENT GRID */}
      <main className="max-w-7xl mx-auto w-full px-6 py-6 flex-1 grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* LEFT COLUMN: ACTIVE VIEW (8 spans of 12) */}
        <section className="lg:col-span-8 flex flex-col gap-6">

          {/* feed segment */}
          {activeSegment === 'feed' && (
            <div className="flex flex-col gap-4">
              <div className="flex justify-between items-center bg-white p-4 rounded-xl border border-neutral-200 shadow-xs">
                <div>
                  <h2 className="text-sm font-semibold text-neutral-800">Experiential Trails Feed</h2>
                  <p className="text-[11px] text-neutral-400 font-sans">Handmade itineraries shared directly by travelers on Postgres</p>
                </div>
                <button 
                  onClick={() => setShowAddPostModal(true)}
                  className="bg-neutral-900 text-white text-xs px-3.5 py-2 font-medium rounded-lg hover:bg-neutral-800 flex items-center gap-1.5 tracking-tight cursor-pointer shadow-sm"
                >
                  <Plus size={14} /> Add Trail Post
                </button>
              </div>

              {posts.length === 0 ? (
                <div className="bg-white p-8 rounded-xl border border-neutral-200 text-center font-mono text-xs text-neutral-500">
                  Zero active trail posts mapped yet. Use "Add Trail Post" to populate tables dynamically.
                </div>
              ) : (
                posts.map(p => (
                  <div key={p.id} className="bg-white rounded-xl border border-neutral-200 overflow-hidden shadow-xs hover:shadow-md transition flex flex-col md:flex-row divide-y md:divide-y-0 md:divide-x divide-neutral-200">
                    
                    {/* Image / Stats */}
                    <div className="md:w-1/3 relative shrink-0">
                      <img 
                        src={p.imageUrl || "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=800"} 
                        alt={p.imageAlt || p.title} 
                        className="w-full h-48 md:h-full object-cover"
                      />
                      <div className="absolute top-2 left-2 bg-neutral-900/80 text-white text-[10px] px-2 py-0.5 rounded font-mono">
                        {p.difficulty || 'Moderate'}
                      </div>
                    </div>

                    {/* Content Detail */}
                    <div className="p-5 flex-1 flex flex-col justify-between">
                      <div>
                        
                        <div className="flex justify-between items-start gap-2 mb-2">
                          <span className="text-[10px] font-mono tracking-wider text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full inline-block">
                            {p.location}
                          </span>
                          <span className="text-[10px] text-neutral-400 font-mono">
                            {p.duration || '3 Days'}
                          </span>
                        </div>

                        <h3 className="text-sm font-semibold text-neutral-800 hover:text-amber-600 cursor-pointer transition mb-2" onClick={() => setSelectedPost(p)}>
                          {p.title}
                        </h3>

                        <p className="text-xs text-neutral-500 line-clamp-3 leading-relaxed mb-4 font-sans">
                          {p.description}
                        </p>

                        {/* Author info & actions */}
                        <div className="flex items-center justify-between border-t border-neutral-100 pt-3">
                          <div className="flex items-center gap-2">
                            <img 
                              src={p.authorAvatar || "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150"} 
                              alt={p.author} 
                              className="w-7 h-7 rounded-full object-cover"
                            />
                            <div className="text-[11px]">
                              <span className="font-semibold text-neutral-800">{p.author}</span>
                              <p className="text-[9px] text-neutral-400">Author</p>
                            </div>
                          </div>

                          <div className="flex items-center gap-2">
                            
                            {/* Voters */}
                            <div className="flex items-center gap-1 bg-neutral-50 border border-neutral-200 px-2 py-1 rounded-md text-xs">
                              <button 
                                onClick={() => handlePostVote(p.id, 1)}
                                className="text-neutral-500 hover:text-amber-600 transition"
                              >
                                <ArrowUp size={12} />
                              </button>
                              <span className="font-mono font-semibold text-neutral-700 min-w-[20px] text-center">
                                {p.votes || 0}
                              </span>
                              <button 
                                onClick={() => handlePostVote(p.id, -1)}
                                className="text-neutral-500 hover:text-amber-600 transition"
                              >
                                <ArrowDown size={12} />
                              </button>
                            </div>

                            <button 
                              onClick={() => setSelectedPost(p)}
                              className="text-[11px] font-semibold text-zinc-900 bg-neutral-100 hover:bg-neutral-200 px-3 py-1.5 rounded-lg transition"
                            >
                              Explore Day Plans
                            </button>

                            {(currentUser.role === 'admin' || currentUser.username === p.author) && (
                              <button 
                                onClick={() => handleDeletePost(p.id)}
                                className="text-red-500 hover:text-white hover:bg-red-500 px-2.5 py-1.5 rounded-lg transition"
                              >
                                <Trash2 size={12} />
                              </button>
                            )}

                          </div>
                        </div>

                      </div>
                    </div>

                  </div>
                ))
              )}
            </div>
          )}

          {/* packages segment */}
          {activeSegment === 'packages' && (
            <div className="flex flex-col gap-4">
              <div className="flex justify-between items-center bg-white p-4 rounded-xl border border-neutral-200 shadow-xs">
                <div>
                  <h2 className="text-sm font-semibold text-neutral-800">Featured Tour Packages</h2>
                  <p className="text-[11px] text-neutral-400 font-sans">Premium packages curated by registered, verified agencies</p>
                </div>
                {currentUser.role === 'agency' && (
                  <button 
                    onClick={() => setShowAddPkgModal(true)}
                    className="bg-neutral-900 text-white text-xs px-3.5 py-2 font-medium rounded-lg hover:bg-neutral-800 flex items-center gap-1.5 tracking-tight cursor-pointer shadow-sm"
                  >
                    <Plus size={14} /> Add Travel Package
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {packages.length === 0 ? (
                  <div className="col-span-full bg-white p-8 rounded-xl border border-neutral-200 text-center font-mono text-xs text-neutral-500">
                    Zero curated travel packages found. Swapped status to agency to create packages.
                  </div>
                ) : (
                  packages.map(pkg => (
                    <div key={pkg.id} className="bg-white rounded-xl border border-neutral-200 overflow-hidden shadow-xs hover:shadow-md transition flex flex-col justify-between">
                      <div className="relative">
                        <img 
                          src={pkg.imageUrl || "https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=1000"} 
                          alt={pkg.imageAlt || pkg.title} 
                          className="w-full h-40 object-cover"
                        />
                        <div className="absolute bottom-2 right-2 bg-neutral-900 text-white text-[10px] px-3 py-1 rounded-md font-semibold font-mono">
                          ${pkg.price} USD
                        </div>
                        <div className="absolute top-2 left-2 bg-emerald-500 text-white text-[9px] uppercase tracking-wide px-2 py-0.5 rounded font-mono">
                          {pkg.status}
                        </div>
                      </div>

                      <div className="p-4">
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-[10px] text-zinc-400 uppercase font-mono tracking-wider">{pkg.destination}</span>
                          <span className="text-xs text-neutral-500 font-medium font-mono">{pkg.duration}</span>
                        </div>
                        <h3 className="text-sm font-semibold text-neutral-800 mb-2 truncate">{pkg.title}</h3>
                        <p className="text-xs text-neutral-500 line-clamp-2 leading-relaxed font-sans mb-3">{pkg.description}</p>
                        
                        <div className="bg-neutral-50 border border-neutral-200 rounded-lg p-2.5 flex justify-between items-center text-[10px] font-mono mb-4">
                          <div>
                            <span className="text-neutral-400 block">Stay Spec</span>
                            <span className="text-neutral-700 font-semibold truncate block max-w-xs">{pkg.stayNameText}</span>
                          </div>
                          <div>
                            <span className="text-neutral-400 block">Stay Rating</span>
                            <span className="text-amber-500 font-semibold block flex items-center gap-0.5">
                              ★ {pkg.stayRating || '4.5'}
                            </span>
                          </div>
                        </div>

                        <div className="flex justify-between items-center border-t border-neutral-100 pt-3">
                          <div className="flex items-center gap-1.5">
                            <span className="w-5 h-5 bg-amber-600 rounded-full flex items-center justify-center text-[10px] font-semibold text-white">
                              {pkg.agencyName[0]}
                            </span>
                            <span className="text-[10px] text-neutral-700 font-semibold truncate block max-w-[120px]">{pkg.agencyName}</span>
                          </div>

                          <div className="flex items-center gap-2">
                            <button 
                              onClick={() => setSelectedPackage(pkg)}
                              className="text-[10px] font-semibold text-neutral-900 bg-neutral-100 hover:bg-neutral-200 px-3 py-2 rounded-lg transition"
                            >
                              Details
                            </button>

                            {(currentUser.role === 'admin' || currentUser.username === pkg.agencyName || currentUser.role === 'agency') && (
                              <button 
                                onClick={() => handleDeletePackage(pkg.id)}
                                className="text-red-500 p-1.5 hover:bg-neutral-100 rounded-lg"
                              >
                                <Trash2 size={12} />
                              </button>
                            )}

                          </div>
                        </div>

                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* agency console segment */}
          {activeSegment === 'agency' && (
            <div className="flex flex-col gap-6">
              
              <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs">
                <h2 className="text-sm font-semibold text-neutral-800 mb-1 flex items-center gap-2">
                  <Award size={16} className="text-amber-600" />
                  Agency Verification Handshake
                </h2>
                <p className="text-xs text-neutral-500 font-sans leading-relaxed mb-4">
                  Request a certified check onto your agency. Our system administrator logs audit trials, reviews submitted credentials on our cloud, matches phone coordinates, and grants authorized licenses to sell premium tour packages.
                </p>

                <form onSubmit={handleAgencyApplyVerification} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11px] text-zinc-500 font-semibold uppercase tracking-wider mb-1">Company legal name</label>
                    <input 
                      type="text" 
                      placeholder="e.g. Everest Trekkers Co." 
                      value={agencyVerifyName}
                      onChange={(e) => setAgencyVerifyName(e.target.value)}
                      className="w-full text-xs px-3 py-2 border border-neutral-200 rounded-lg focus:outline-none focus:border-amber-500"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-zinc-500 font-semibold uppercase tracking-wider mb-1">Business coordinate email</label>
                    <input 
                      type="email" 
                      placeholder="e.g. verify@agency.io" 
                      value={agencyVerifyEmail}
                      onChange={(e) => setAgencyVerifyEmail(e.target.value)}
                      className="w-full text-xs px-3 py-2 border border-neutral-200 rounded-lg focus:outline-none focus:border-amber-500"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-zinc-500 font-semibold uppercase tracking-wider mb-1">Office Contact Phone</label>
                    <input 
                      type="text" 
                      placeholder="e.g. +977-1-443213" 
                      value={agencyVerifyPhone}
                      onChange={(e) => setAgencyVerifyPhone(e.target.value)}
                      className="w-full text-xs px-3 py-2 border border-neutral-200 rounded-lg focus:outline-none focus:border-amber-500"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-zinc-500 font-semibold uppercase tracking-wider mb-1">Licensing Files quantity attached</label>
                    <select 
                      value={agencyFilesCount}
                      onChange={(e) => setAgencyFilesCount(e.target.value)}
                      className="w-full text-xs px-3 py-2 border border-neutral-200 rounded-lg focus:outline-none focus:border-amber-500 bg-white"
                    >
                      <option value="1">1 File (Identity Check)</option>
                      <option value="2">2 Files (Local License + TAX registration)</option>
                      <option value="3">3 Files (Tourism Board Premium Bond)</option>
                    </select>
                  </div>
                  
                  <div className="md:col-span-full pt-2">
                    <button 
                      type="submit" 
                      className="w-full bg-amber-600 text-white text-xs py-2 px-4 rounded-lg hover:bg-amber-700 transition font-semibold"
                    >
                      Submit Verification Request
                    </button>
                  </div>
                </form>
              </div>

              {/* Package addition dashboard if verified */}
              <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs">
                <div className="flex justify-between items-center mb-4">
                  <div>
                    <h3 className="text-xs font-semibold text-neutral-800 uppercase tracking-widest font-mono">My Listed Agency Proposals ({packages.length})</h3>
                    <p className="text-[11px] text-neutral-400">Manage packages listed in database</p>
                  </div>
                  <button 
                    onClick={() => setShowAddPkgModal(true)}
                    className="bg-neutral-900 text-white text-xs px-3.5 py-1.5 font-medium rounded-lg hover:bg-neutral-800 cursor-pointer flex items-center gap-1 shadow-sm"
                  >
                    <Plus size={12} /> Live Tour Package
                  </button>
                </div>

                <div className="divide-y divide-neutral-200">
                  {packages.map(pkg => (
                    <div key={pkg.id} className="py-3 flex justify-between items-center">
                      <div className="flex items-center gap-3">
                        <img src={pkg.imageUrl} alt={pkg.title} className="w-10 h-10 object-cover rounded-lg shrink-0 border" />
                        <div>
                          <p className="text-xs font-semibold text-neutral-800">{pkg.title}</p>
                          <span className="text-[9px] font-mono text-zinc-400">{pkg.destination} &bull; ${pkg.price} USD</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="bg-emerald-100 text-emerald-800 text-[9px] px-2 py-0.5 rounded font-mono mr-2">Active</span>
                        
                        <button 
                          onClick={() => handleDeletePackage(pkg.id)}
                          className="text-red-500 hover:text-red-700 p-1.5"
                        >
                          <Trash2 size={12} />
                        </button>
                        
                      </div>
                    </div>
                  ))}
                  {packages.length === 0 && (
                    <div className="text-center py-6 text-xs text-neutral-400 font-mono">
                      No active package listings submitted. Use option above to insert nodes.
                    </div>
                  )}
                </div>
              </div>

            </div>
          )}

          {/* admin board segment */}
          {activeSegment === 'admin' && (
            <div className="flex flex-col gap-6">
              
              {/* Verification Applications queue */}
              <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs">
                <h3 className="text-xs font-bold font-mono uppercase tracking-widest text-neutral-800 mb-3 flex items-center gap-2">
                  <CheckCircle size={14} className="text-emerald-500" />
                  Authorized Verification Applications ({verifications.length})
                </h3>
                
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs divide-y divide-neutral-200">
                    <thead>
                      <tr className="text-neutral-400 font-mono text-[10px] uppercase">
                        <th className="py-2">Agency Partner Name</th>
                        <th className="py-2">Coordinate Email</th>
                        <th className="py-2">Phone</th>
                        <th className="py-2">Attached Files</th>
                        <th className="py-2">Status</th>
                        <th className="py-2 text-right">Option</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-100">
                      {verifications.map(v => (
                        <tr key={v.id} className="text-neutral-700">
                          <td className="py-2.5 font-semibold text-neutral-900">{v.companyName}</td>
                          <td className="py-2.5">{v.email}</td>
                          <td className="py-2.5 font-mono">{v.phone}</td>
                          <td className="py-2.5 font-mono">{v.filesCount} file(s)</td>
                          <td className="py-2.5">
                            <span className={`px-2 py-0.5 rounded text-[9px] font-semibold uppercase ${
                              v.status === 'resolved' 
                                ? 'bg-emerald-100 text-emerald-800' 
                                : 'bg-amber-100 text-amber-800 animate-pulse'
                            }`}>
                              {v.status}
                            </span>
                          </td>
                          <td className="py-2.5 text-right">
                            {v.status === 'pending' && (
                              <button 
                                onClick={() => handleApproveAgency(v.id)}
                                className="bg-emerald-600 text-white text-[10px] font-semibold px-2 py-1 rounded hover:bg-emerald-700 transition"
                              >
                                Approve hand
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                      {verifications.length === 0 && (
                        <tr>
                          <td colSpan="6" className="text-center py-4 font-mono text-neutral-400">
                            Verification application queues are clean.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* flagged posts / moderation queue */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs">
                  <h3 className="text-xs font-bold font-mono uppercase tracking-widest text-neutral-800 mb-3 flex items-center gap-2">
                    <AlertTriangle size={14} className="text-amber-500" />
                    Flagged Post reports ({flaggedPosts.length})
                  </h3>

                  <div className="divide-y divide-neutral-200">
                    {flaggedPosts.map(fp => (
                      <div key={fp.id} className="py-3">
                        <div className="flex justify-between items-start mb-1 text-[11px]">
                          <span className="font-semibold text-neutral-800">{fp.username}</span>
                          <span className="text-red-600 bg-red-50 font-mono text-[9px] px-1.5 rounded">{fp.type}</span>
                        </div>
                        <p className="text-xs text-neutral-500 font-sans italic leading-relaxed bg-neutral-50 p-2 rounded border mb-2">
                          "{fp.content}"
                        </p>
                        <div className="flex justify-end gap-2">
                          <button 
                            onClick={() => handleResolveFlaggedPost(fp.id)}
                            className="bg-neutral-900 text-white text-[10px] font-medium px-2 py-1 rounded-md hover:bg-neutral-800 transition"
                          >
                            Dismiss flag
                          </button>
                        </div>
                      </div>
                    ))}
                    {flaggedPosts.length === 0 && (
                      <div className="text-center py-6 text-xs text-neutral-400 font-mono">
                        Flagged posts queue is clean.
                      </div>
                    )}
                  </div>
                </div>

                <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs">
                  <h3 className="text-xs font-bold font-mono uppercase tracking-widest text-neutral-800 mb-3 flex items-center gap-2">
                    <AlertTriangle size={14} className="text-amber-500" />
                    Comment Moderation flagging ({commentReports.length})
                  </h3>

                  <div className="divide-y divide-neutral-200">
                    {commentReports.map(cr => (
                      <div key={cr.id} className="py-3">
                        <div className="flex justify-between items-center mb-1 text-[11px]">
                          <span className="font-semibold text-neutral-800">{cr.username}</span>
                          <span className="text-zinc-500 font-mono text-[10px]">Reports count: {cr.reportsCount}</span>
                        </div>
                        <p className="text-xs text-neutral-500 font-sans italic leading-relaxed bg-neutral-50 p-2 rounded border mb-2">
                          "{cr.text}"
                        </p>
                        <div className="flex justify-between items-center">
                          <span className="text-[9px] font-mono text-zinc-400 truncate max-w-[120px]">Post: {cr.postTitle}</span>
                          <div className="flex gap-2">
                            <button 
                              onClick={() => handleResolveCommentReport(cr.id)}
                              className="bg-neutral-900 text-white text-[10px] font-medium px-2 py-1 rounded-md hover:bg-neutral-800 transition"
                            >
                              Resolve
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                    {commentReports.length === 0 && (
                      <div className="text-center py-6 text-xs text-neutral-400 font-mono">
                        No pending comments flags active.
                      </div>
                    )}
                  </div>
                </div>

              </div>

              {/* Database audit logs */}
              <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs">
                <h3 className="text-xs font-bold font-mono uppercase tracking-widest text-neutral-800 mb-3 flex items-center gap-2">
                  <FileText size={14} className="text-amber-600" />
                  PostgreSQL Real-Time System Audit Logs ({auditLogs.length})
                </h3>

                <div className="max-h-72 overflow-y-auto border rounded-lg bg-zinc-950 font-mono text-[10px] text-neutral-300 p-4 divide-y divide-neutral-800 flex flex-col gap-2">
                  {auditLogs.map((log) => (
                    <div key={log.id} className="py-1 flex flex-col md:flex-row justify-between gap-2">
                      <div>
                        <span className="text-amber-500 font-semibold uppercase">[ {log.entityType} {log.action} ]</span>
                        <span className="text-neutral-400 ml-1">ID: {log.entityId} performed by "{log.performedBy}"</span>
                        <p className="text-neutral-500 mt-0.5 truncate max-w-xl">{log.details || 'No structural payload details'}</p>
                      </div>
                      <span className="text-[9px] text-zinc-500 shrink-0 text-right">
                        {new Date(log.timestamp).toLocaleTimeString() || log.timestamp}
                      </span>
                    </div>
                  ))}
                  {auditLogs.length === 0 && (
                    <div className="text-center py-6 text-[10px] text-neutral-400 font-mono">
                      Establishing database connection handshake... Click toggle to retrieve.
                    </div>
                  )}
                </div>
              </div>

            </div>
          )}

        </section>

        {/* RIGHT COLUMN: APP PERSPECTIVE PANEL (4 spans of 12) */}
        <section className="lg:col-span-4 flex flex-col gap-6">
          
          {/* USER ACTIVE DETAILS CARD */}
          <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-amber-600/5 rounded-full blur-xl translate-x-4 -translate-y-4"></div>
            
            <span className="text-[9px] font-mono uppercase bg-amber-50 text-amber-800 px-2 py-0.5 rounded font-bold">
              Account Sync Check
            </span>

            <div className="flex items-center gap-3 mt-4 mb-3">
              <img 
                src={currentUser.role === 'admin' 
                  ? "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150" 
                  : "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150"
                } 
                alt="user avatar pointer" 
                className="w-10 h-10 rounded-full border border-neutral-200 object-cover"
              />
              <div>
                <h4 className="text-xs font-semibold text-neutral-800">{currentUser.username}</h4>
                <p className="text-[10px] text-neutral-400 font-mono truncate max-w-[180px]">{currentUser.email}</p>
              </div>
            </div>

            <p className="text-xs text-neutral-500 leading-relaxed italic font-sans border-l-2 pl-3 mb-4">
              "{currentUser.bio || 'No personalized autobiography details synchronised yet.'}"
            </p>

            <div className="flex justify-between items-center gap-2 border-t border-neutral-100 pt-3 text-[11px]">
              <span className="text-neutral-400">PostgreSQL Status:</span>
              <span className="bg-emerald-50 text-emerald-800 border border-emerald-200 px-2 py-0.5 rounded font-mono font-medium">
                HANDSHAKE_LIVE
              </span>
            </div>

            <button 
              onClick={openProfileEdit}
              className="w-full mt-4 bg-neutral-900 hover:bg-neutral-800 text-white text-xs py-2 rounded-lg font-semibold flex items-center justify-center gap-1.5 transition"
            >
              <Settings size={12} /> Edit Account Info
            </button>
          </div>

          {/* TRAVEL MAP PREVIEW */}
          <div className="bg-white rounded-xl border border-neutral-200 overflow-hidden shadow-xs">
            <div className="p-4 border-b border-neutral-100">
              <h3 className="text-xs font-bold font-mono tracking-widest uppercase text-neutral-800 flex items-center gap-1">
                <Map size={14} className="text-amber-600" />
                Vazhikal Scenic Radar
              </h3>
            </div>
            
            <div className="p-4 bg-neutral-50 flex flex-col justify-center items-center text-center py-8">
              <img 
                src="https://images.unsplash.com/photo-1524661135-423995f22d0b?w=40 w-150-150" 
                alt="map pin" 
                className="w-12 h-12 rounded-full border shadow-sm mb-3 object-cover"
              />
              <span className="text-[10px] text-neutral-500 font-mono flex items-center gap-1 mb-1">
                <MapPin size={10} className="text-amber-600" />
                Kyoto, Japan Radar Cluster
              </span>
              <p className="text-[11px] text-neutral-400 max-w-[200px] leading-relaxed mb-4">
                Moss-covered shrines, autumn forests, and local agencies mapping trails in Japan.
              </p>
              <button 
                onClick={() => handleSwitchUserRole('traveller')}
                className="text-[10px] bg-neutral-900 hover:bg-neutral-800 text-white font-semibold py-1.5 px-3 rounded-md transition"
              >
                Track Live Map
              </button>
            </div>
          </div>

          {/* CLOCK & SEED DB INSTRUCTION PANEL */}
          <div className="bg-neutral-900 rounded-xl p-5 border border-zinc-800 text-white shadow-lg relative overflow-hidden">
            
            <h4 className="text-xs font-mono uppercase tracking-widest text-amber-400 mb-1">Setup DB Helper</h4>
            <p className="text-[11px] text-zinc-400 leading-relaxed mb-4 font-sans">
              To verify and synchronize all 8 persistent modules on your laptop:
            </p>

            <div className="space-y-2 border-t border-zinc-800 pt-3 text-[10px] font-mono text-zinc-300">
              <div className="flex gap-2">
                <span className="text-amber-500 font-semibold">1.</span>
                <span>Run <code className="bg-zinc-800 px-1 rounded text-amber-300">python setup_db.py</code> to automatically initialize databases.</span>
              </div>
              <div className="flex gap-2">
                <span className="text-amber-500 font-semibold">2.</span>
                <span>The system boots on separate ports, perfectly mapped.</span>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-zinc-800 flex justify-between items-center text-[9px] text-zinc-500 font-mono">
              <span>DB Server: TS/Postgres</span>
              <span className="text-emerald-500">✔ ON-GRID</span>
            </div>

          </div>

        </section>

      </main>

      {/* SLIDE-OVER MODALS (AnimatePresence) */}
      
      {/* 1. Post Detail slideover */}
      <AnimatePresence>
        {selectedPost && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/65 backdrop-blur-xs flex justify-end"
            onClick={() => setSelectedPost(null)}
          >
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 24, stiffness: 220 }}
              className="bg-white w-full max-w-xl h-full shadow-2xl flex flex-col justify-between overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div>
                {/* Header photo */}
                <div className="relative h-64 bg-neutral-100">
                  <img 
                    src={selectedPost.imageUrl || "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=800"} 
                    alt={selectedPost.imageAlt || selectedPost.title} 
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
                  <button 
                    onClick={() => setSelectedPost(null)}
                    className="absolute top-4 right-4 bg-white/20 hover:bg-white/40 text-white rounded-full p-2 backdrop-blur-xs transition"
                  >
                    <X size={16} />
                  </button>

                  <div className="absolute bottom-4 left-6 text-white pr-6">
                    <span className="bg-amber-600 font-mono text-[9px] uppercase tracking-wider px-2 py-0.5 rounded">
                      {selectedPost.location}
                    </span>
                    <h2 className="text-base font-bold mt-2 font-sans leading-tight">
                      {selectedPost.title}
                    </h2>
                  </div>
                </div>

                {/* Meta details strip */}
                <div className="bg-neutral-50 px-6 py-3 border-b border-neutral-100 flex justify-between items-center text-xs">
                  <div className="flex items-center gap-2">
                    <img src={selectedPost.authorAvatar} alt="avatar" className="w-6 h-6 rounded-full object-cover" />
                    <span className="font-semibold text-neutral-800">{selectedPost.author}</span>
                  </div>
                  <div className="flex gap-4 text-neutral-500 font-mono text-[11px]">
                    <span>Cost: <b className="text-neutral-800">{selectedPost.cost}</b></span>
                    <span>Duration: <b className="text-neutral-800">{selectedPost.duration}</b></span>
                  </div>
                </div>

                {/* Description & Day specifications */}
                <div className="p-6 flex flex-col gap-6">
                  
                  <div>
                    <h3 className="text-xs font-bold font-mono uppercase tracking-widest text-zinc-400 mb-2">Introduction</h3>
                    <p className="text-xs text-neutral-600 leading-relaxed font-sans">{selectedPost.description}</p>
                  </div>

                  <div>
                    <h3 className="text-xs font-bold font-mono uppercase tracking-widest text-zinc-400 mb-4">Detailed Day Plan</h3>
                    
                    <div className="space-y-6 pl-2 border-l border-amber-600/20">
                      {selectedPost.dayByDay && selectedPost.dayByDay.map((plan, i) => (
                        <div key={i} className="relative pl-6">
                          {/* Dot indicator */}
                          <div className="absolute -left-[13px] top-1.5 w-6 h-6 rounded-full bg-amber-50 border-2 border-amber-600 flex items-center justify-center text-[10px] font-bold text-amber-700">
                            {plan.day || i+1}
                          </div>

                          <h4 className="text-xs font-bold text-neutral-800 font-sans mb-1">{plan.title}</h4>
                          <p className="text-xs text-neutral-500 leading-relaxed font-sans mb-2">{plan.description}</p>
                          
                          <div className="flex flex-wrap gap-1.5">
                            {plan.badges && plan.badges.map((badge, bIdx) => (
                              <span key={bIdx} className="bg-neutral-100 text-neutral-600 text-[9px] px-2 py-0.5 rounded font-mono">
                                {badge}
                              </span>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Comments list section */}
                  <div className="border-t border-neutral-100 pt-6">
                    <h3 className="text-xs font-bold font-mono uppercase tracking-widest text-zinc-400 mb-4">
                      Comments Branch Room ({selectedPost.comments ? selectedPost.comments.length : 0})
                    </h3>

                    {/* Add Root Comment Form */}
                    <form 
                      onSubmit={(e) => handleSubmitComment(e, selectedPost.id)}
                      className="flex gap-2 mb-4"
                    >
                      <input 
                        type="text" 
                        placeholder="Add your public inquiry or discussion note..."
                        value={commentTexts[`post_${selectedPost.id}`] || ''}
                        onChange={(e) => setCommentTexts({ ...commentTexts, [`post_${selectedPost.id}`]: e.target.value })}
                        className="flex-1 text-xs px-3 py-2 border border-neutral-200 rounded-lg focus:outline-none focus:border-amber-500"
                        required
                      />
                      <button 
                        type="submit"
                        className="bg-neutral-900 text-white text-xs px-4 py-2 rounded-lg font-semibold hover:bg-neutral-800 transition"
                      >
                        Comment
                      </button>
                    </form>

                    {/* Dynamic tree layout rendering */}
                    <div className="space-y-3">
                      {selectedPost.comments && selectedPost.comments.map(comment => renderCommentNode(comment, selectedPost.id))}
                      {(!selectedPost.comments || selectedPost.comments.length === 0) && (
                        <div className="text-center py-6 text-xs text-neutral-400 font-mono">
                          Zero comments on this trail post. Be the first to initiate inquiry!
                        </div>
                      )}
                    </div>

                  </div>

                </div>
              </div>

              {/* Bottom bar */}
              <div className="bg-neutral-50 p-4 border-t border-neutral-100 flex justify-between items-center text-xs">
                <span className="text-[10px] text-neutral-400 font-mono">Post Entity Node ID: {selectedPost.id}</span>
                <button 
                  onClick={() => setSelectedPost(null)}
                  className="bg-neutral-900 text-white px-4 py-1.5 rounded-lg font-semibold hover:bg-amber-600 transition"
                >
                  Close Explore Panel
                </button>
              </div>

            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 2. Curated Package Detail slideover */}
      <AnimatePresence>
        {selectedPackage && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/65 backdrop-blur-xs flex justify-end"
            onClick={() => setSelectedPackage(null)}
          >
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 24, stiffness: 220 }}
              className="bg-white w-full max-w-xl h-full shadow-2xl flex flex-col justify-between overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div>
                
                {/* Header photo banner */}
                <div className="relative h-64 bg-neutral-100">
                  <img 
                    src={selectedPackage.imageUrl || "https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=1000"} 
                    alt={selectedPackage.title} 
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
                  <button 
                    onClick={() => setSelectedPackage(null)}
                    className="absolute top-4 right-4 bg-white/20 hover:bg-white/40 text-white rounded-full p-2 backdrop-blur-xs transition"
                  >
                    <X size={16} />
                  </button>

                  <div className="absolute bottom-4 left-6 text-white pr-6">
                    <span className="bg-emerald-600 font-mono text-[9px] uppercase tracking-wider px-2 py-0.5 rounded font-bold">
                      {selectedPackage.destination}
                    </span>
                    <h2 className="text-base font-bold mt-2 font-sans leading-tight">
                      {selectedPackage.title}
                    </h2>
                  </div>
                </div>

                {/* Price strip */}
                <div className="bg-amber-50 border-y border-amber-100 px-6 py-4 flex justify-between items-center text-xs">
                  <div>
                    <span className="text-[10px] text-amber-800 uppercase font-mono block">Package Fair Direct Price</span>
                    <span className="text-base font-bold text-neutral-900">${selectedPackage.price} USD</span>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-amber-800 uppercase font-mono block">Curated agency Partner</span>
                    <span className="text-xs font-semibold text-neutral-800">{selectedPackage.agencyName}</span>
                  </div>
                </div>

                {/* Package detail contents */}
                <div className="p-6 flex flex-col gap-6">
                  
                  <div>
                    <h3 className="text-xs font-bold font-mono uppercase tracking-widest text-zinc-400 mb-2">Offer Overview</h3>
                    <p className="text-xs text-neutral-600 leading-relaxed font-sans">{selectedPackage.description}</p>
                  </div>

                  <div>
                    <h3 className="text-xs font-bold font-mono uppercase tracking-widest text-zinc-400 mb-3">Residential Stay details</h3>
                    <div className="border border-neutral-200 rounded-xl p-4 bg-neutral-50 flex flex-col md:flex-row gap-4 divide-y md:divide-y-0 md:divide-x divide-neutral-200">
                      <div className="flex-1">
                        <span className="text-[10px] text-zinc-400 font-mono uppercase block">Suites / Hotel</span>
                        <span className="text-xs font-semibold text-neutral-800 block mb-1">{selectedPackage.stayNameText}</span>
                        <p className="text-[11px] text-neutral-500 font-sans">{selectedPackage.stayDescText}</p>
                      </div>
                      <div className="md:pl-4 md:w-28 shrink-0 flex flex-col items-center justify-center pt-2 md:pt-0">
                        <span className="text-[10px] text-zinc-400 font-mono uppercase">Resort Rating</span>
                        <div className="text-amber-500 font-mono font-bold text-sm tracking-tight flex items-center mt-1">
                          ★ {selectedPackage.stayRating || '4.9'}
                        </div>
                        <span className="text-[9px] text-zinc-400">({selectedPackage.stayReviewsCount || 10} reviews)</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-xs font-bold font-mono uppercase tracking-widest text-zinc-400 mb-2">Luxury inclusions</h3>
                    <ul className="space-y-1.5 pl-2">
                      {selectedPackage.inclusions && selectedPackage.inclusions.map((inc, i) => (
                        <li key={i} className="text-xs text-neutral-600 flex items-start gap-1.5">
                          <Check size={12} className="text-amber-600 mt-1 shrink-0" />
                          <span>{inc}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                </div>

              </div>

              {/* Bottom bar */}
              <div className="bg-neutral-50 p-4 border-t border-neutral-100 flex justify-between items-center text-xs">
                <span className="text-[10px] text-neutral-400 font-mono">Package Entity Node ID: {selectedPackage.id}</span>
                <button 
                  onClick={() => setSelectedPackage(null)}
                  className="bg-neutral-900 text-white px-4 py-1.5 rounded-lg font-semibold hover:bg-emerald-600 transition"
                >
                  Close details
                </button>
              </div>

            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 3. Add Post Modal Component */}
      {showAddPostModal && (
        <div className="fixed inset-0 z-50 bg-black/65 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-xl rounded-xl border p-6 flex flex-col gap-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center border-b pb-3">
              <h3 className="text-sm font-semibold text-neutral-800">Add Experiential Trail Post</h3>
              <button onClick={() => setShowAddPostModal(false)} className="text-zinc-400 hover:text-zinc-600">
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleAddPostSubmit} className="space-y-4 text-xs select-none">
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] text-zinc-500 font-semibold mb-1 uppercase tracking-wider">Itinerary Trail Title</label>
                  <input 
                    type="text" 
                    placeholder="e.g. Kyoto Moss Shrine Hike" 
                    value={postTitle}
                    onChange={(e) => setPostTitle(e.target.value)}
                    className="w-full text-xs px-3 py-2 border rounded-lg focus:outline-none focus:border-amber-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-zinc-500 font-semibold mb-1 uppercase tracking-wider">Target Location Coordinates</label>
                  <input 
                    type="text" 
                    placeholder="e.g. Kyoto, Japan" 
                    value={postLoc}
                    onChange={(e) => setPostLoc(e.target.value)}
                    className="w-full text-xs px-3 py-2 border rounded-lg focus:outline-none focus:border-amber-500"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] text-zinc-500 font-semibold mb-1 uppercase tracking-wider">Experience Synopsis</label>
                <textarea 
                  placeholder="Summarize the key highlights and vibe of this specific itinerary..." 
                  value={postDesc}
                  onChange={(e) => setPostDesc(e.target.value)}
                  className="w-full text-xs px-3 py-2 border rounded-lg h-20 focus:outline-none focus:border-amber-500"
                  required
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-[11px] text-zinc-500 font-semibold mb-1 uppercase tracking-wider">Total Est. Cost</label>
                  <input 
                    type="text" 
                    placeholder="e.g. $450 USD" 
                    value={postCost}
                    onChange={(e) => setPostCost(e.target.value)}
                    className="w-full text-xs px-3 py-2 border rounded-lg focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-zinc-500 font-semibold mb-1 uppercase tracking-wider">Suggested Duration</label>
                  <input 
                    type="text" 
                    placeholder="e.g. 3 Days, 2 Nights" 
                    value={postDuration}
                    onChange={(e) => setPostDuration(e.target.value)}
                    className="w-full text-xs px-3 py-2 border rounded-lg focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-zinc-500 font-semibold mb-1 uppercase tracking-wider">Difficulty Level</label>
                  <select 
                    value={postDifficulty}
                    onChange={(e) => setPostDifficulty(e.target.value)}
                    className="w-full text-xs px-3 py-2 border rounded-lg focus:outline-none focus:border-amber-500 bg-white"
                  >
                    <option value="Easy">Easy</option>
                    <option value="Moderate">Moderate</option>
                    <option value="Challenging">Challenging</option>
                  </select>
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="block text-[11px] text-zinc-500 font-semibold uppercase tracking-wider">Specific day actions (Itinerary structure)</label>
                  <button 
                    type="button"
                    onClick={() => setPostDays([...postDays, { day: postDays.length + 1, title: '', description: '', badges: '' }])}
                    className="text-xs text-amber-600 hover:text-amber-800 font-semibold flex items-center gap-0.5"
                  >
                    + Add Day Node
                  </button>
                </div>

                <div className="space-y-3">
                  {postDays.map((d, dIdx) => (
                    <div key={dIdx} className="bg-neutral-50 p-3 rounded-lg border border-neutral-200">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="font-bold text-amber-700 font-mono text-xs">Day {d.day}:</span>
                        <input 
                          type="text" 
                          placeholder="Day general heading title..."
                          value={d.title}
                          onChange={(e) => {
                            const clone = [...postDays];
                            clone[dIdx].title = e.target.value;
                            setPostDays(clone);
                          }}
                          className="flex-1 text-xs px-2 py-1 border rounded focus:outline-none"
                          required
                        />
                      </div>
                      <textarea 
                        placeholder="Define detailed sights visited, tea tests or temple statue highlights..."
                        value={d.description}
                        onChange={(e) => {
                          const clone = [...postDays];
                          clone[dIdx].description = e.target.value;
                          setPostDays(clone);
                        }}
                        className="w-full text-xs px-2 py-1 border rounded h-14 focus:outline-none mb-2"
                        required
                      />
                      <input 
                        type="text" 
                        placeholder="Key Tags (comma separated, e.g. Matcha, Zen, Hike)"
                        value={d.badges}
                        onChange={(e) => {
                          const clone = [...postDays];
                          clone[dIdx].badges = e.target.value;
                          setPostDays(clone);
                        }}
                        className="w-full text-xs px-2 py-1 border rounded focus:outline-none"
                      />
                    </div>
                  ))}
                </div>
              </div>

              <div className="border-t pt-3 flex justify-end gap-2 text-xs">
                <button 
                  type="button" 
                  onClick={() => setShowAddPostModal(false)}
                  className="bg-neutral-100 hover:bg-neutral-200 text-neutral-700 px-4 py-2 rounded-lg font-semibold"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="bg-neutral-900 hover:bg-neutral-800 text-white px-5 py-2 rounded-lg font-semibold"
                >
                  Record Trail In Database
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* 4. Add Package Modal Component */}
      {showAddPkgModal && (
        <div className="fixed inset-0 z-50 bg-black/65 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-xl rounded-xl border p-6 flex flex-col gap-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center border-b pb-3">
              <h3 className="text-sm font-semibold text-neutral-800">Publish Curated Tour Package</h3>
              <button onClick={() => setShowAddPkgModal(false)} className="text-zinc-400 hover:text-zinc-600">
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleAddPkgSubmit} className="space-y-4 text-xs">
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] text-zinc-500 font-semibold mb-1 uppercase tracking-wider">Tour Title</label>
                  <input 
                    type="text" 
                    placeholder="e.g. 7-Day Swiss Alps Luxury Scenic" 
                    value={pkgTitle}
                    onChange={(e) => setPkgTitle(e.target.value)}
                    className="w-full text-xs px-3 py-2 border rounded-lg focus:outline-none focus:border-amber-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-zinc-500 font-semibold mb-1 uppercase tracking-wider">Destination</label>
                  <input 
                    type="text" 
                    placeholder="e.g. Zermatt, Switzerland" 
                    value={pkgDest}
                    onChange={(e) => setPkgDest(e.target.value)}
                    className="w-full text-xs px-3 py-2 border rounded-lg focus:outline-none focus:border-amber-500"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-[11px] text-zinc-500 font-semibold mb-1 uppercase tracking-wider">Price (USD)</label>
                  <input 
                    type="number" 
                    value={pkgPrice}
                    onChange={(e) => setPkgPrice(e.target.value)}
                    className="w-full text-xs px-3 py-2 border rounded-lg focus:outline-none focus:border-amber-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-zinc-500 font-semibold mb-1 uppercase tracking-wider">Suggested Duration</label>
                  <input 
                    type="text" 
                    placeholder="e.g. 5 Days, 4 Nights" 
                    value={pkgDuration}
                    onChange={(e) => setPkgDuration(e.target.value)}
                    className="w-full text-xs px-3 py-2 border rounded-lg focus:outline-none focus:border-amber-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-zinc-500 font-semibold mb-1 uppercase tracking-wider">Inclusions (CSV)</label>
                  <input 
                    type="text" 
                    placeholder="e.g. Hotel passes, Local Food, Private Car" 
                    value={pkgInclusions}
                    onChange={(e) => setPkgInclusions(e.target.value)}
                    className="w-full text-xs px-3 py-2 border rounded-lg focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] text-zinc-500 font-semibold mb-1 uppercase tracking-wider">Offer description</label>
                <textarea 
                  placeholder="Detail the package benefits, scenic points, and general tour details..." 
                  value={pkgDesc}
                  onChange={(e) => setPkgDesc(e.target.value)}
                  className="w-full text-xs px-3 py-2 border rounded-lg h-20 focus:outline-none focus:border-amber-500 bg-white"
                  required
                />
              </div>

              <div className="bg-neutral-50 p-4 rounded-xl border space-y-3">
                <span className="text-[10px] uppercase font-mono tracking-wider font-semibold text-neutral-400 block">Proposed Stay specifications</span>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11px] text-zinc-500 font-semibold mb-1">Hotel Suite name</label>
                    <input 
                      type="text" 
                      placeholder="e.g. Azure Beachfront Villas" 
                      value={pkgStayName}
                      onChange={(e) => setPkgStayName(e.target.value)}
                      className="w-full text-xs px-3 py-2 border rounded-lg bg-white focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-zinc-500 font-semibold mb-1">Stay Description highlights</label>
                    <input 
                      type="text" 
                      placeholder="e.g. 5-star mountain suites with pool" 
                      value={pkgStayDesc}
                      onChange={(e) => setPkgStayDesc(e.target.value)}
                      className="w-full text-xs px-3 py-2 border rounded-lg bg-white focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              <div className="border-t pt-3 flex justify-end gap-2 text-xs">
                <button 
                  type="button" 
                  onClick={() => setShowAddPkgModal(false)}
                  className="bg-neutral-100 hover:bg-neutral-200 text-neutral-700 px-4 py-2 rounded-lg font-semibold"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="bg-neutral-900 hover:bg-neutral-800 text-white px-5 py-2 rounded-lg font-semibold"
                >
                  Publish Package
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* 5. Edit Account Profile Coordinates Modal */}
      {showEditProfileModal && (
        <div className="fixed inset-0 z-50 bg-black/65 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-xl border p-6 flex flex-col gap-4">
            <div className="flex justify-between items-center border-b pb-3">
              <h3 className="text-sm font-semibold text-neutral-800">Synchronize Account Coordinates</h3>
              <button onClick={() => setShowEditProfileModal(false)} className="text-zinc-400 hover:text-zinc-600">
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleEditProfileSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-[11px] text-zinc-500 font-semibold mb-1 uppercase tracking-wider">Username ID handle</label>
                <input 
                  type="text" 
                  value={profileUsername}
                  onChange={(e) => setProfileUsername(e.target.value)}
                  className="w-full text-xs px-3 py-2 border rounded-lg focus:outline-none focus:border-amber-500"
                  required
                />
              </div>

              <div>
                <label className="block text-[11px] text-zinc-500 font-semibold mb-1 uppercase tracking-wider">Email coordinate</label>
                <input 
                  type="email" 
                  value={profileEmail}
                  onChange={(e) => setProfileEmail(e.target.value)}
                  className="w-full text-xs px-3 py-2 border rounded-lg focus:outline-none focus:border-amber-500"
                  required
                />
                <span className="text-[10px] text-neutral-400 mt-1 block">Your email is used to tie your PostgreSQL database record.</span>
              </div>

              <div>
                <label className="block text-[11px] text-zinc-500 font-semibold mb-1 uppercase tracking-wider">Biography summary</label>
                <textarea 
                  value={profileBio}
                  onChange={(e) => setProfileBio(e.target.value)}
                  className="w-full text-xs px-3 py-2 border rounded-lg h-24 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="border-t pt-3 flex justify-end gap-2">
                <button 
                  type="button" 
                  onClick={() => setShowEditProfileModal(false)}
                  className="bg-neutral-100 hover:bg-neutral-200 text-neutral-700 px-4 py-2 rounded-lg font-semibold"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="bg-neutral-900 hover:bg-neutral-800 text-white px-5 py-2 rounded-lg font-semibold"
                >
                  Synchronize on Postgres
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
