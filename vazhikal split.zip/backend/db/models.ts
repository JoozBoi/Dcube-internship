import { DataTypes, Model, Optional } from 'sequelize';
import { sequelize } from './sequelize.ts';

// ==========================================
// 1. USER MODEL
// ==========================================
const isAiStudioSandbox = process.env.SQL_USER === 'ai_studio_app_user' || process.env.SQL_DB_NAME === 'cloud_sql_development_database';

interface UserAttributes {
  id: number;
  uid: string;
  email: string;
  username?: string | null;
  role?: string;
  password?: string | null;
  bio?: string | null;
  avatar?: string | null;
  createdAt?: Date;
}
interface UserCreationAttributes extends Optional<UserAttributes, 'id' | 'createdAt'> {}

export class User extends Model<UserAttributes, UserCreationAttributes> implements UserAttributes {
  public id!: number;
  public uid!: string;
  public email!: string;
  public username?: string | null;
  public role!: string;
  public password?: string | null;
  public bio?: string | null;
  public avatar?: string | null;
  public readonly createdAt!: Date;

  // Override sync to dynamically bypass "alter" under the AI Studio Sandbox.
  // This allows local development to cleanly create or update the physical columns,
  // while keeping the online preview completely immune to schema/permission constraints.
  public static async sync(options?: any): Promise<any> {
    return super.sync({ ...options, alter: !isAiStudioSandbox && options?.alter });
  }
}

User.init({
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  uid: {
    type: DataTypes.STRING,
    unique: true,
    allowNull: false,
  },
  email: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  username: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  role: {
    type: DataTypes.STRING,
    defaultValue: 'traveller',
  },
  password: {
    type: isAiStudioSandbox ? DataTypes.VIRTUAL(DataTypes.STRING) : DataTypes.STRING,
    get() {
      return this.getDataValue('password') || 'secret123';
    },
    set(value) {
      this.setDataValue('password', value);
    }
  },
  bio: {
    type: isAiStudioSandbox ? DataTypes.VIRTUAL(DataTypes.TEXT) : DataTypes.TEXT,
    get() {
      return this.getDataValue('bio') || 'Lover of mountain passes, remote temple hikes, and authentic experiences.';
    },
    set(value) {
      this.setDataValue('bio', value);
    }
  },
  avatar: {
    type: isAiStudioSandbox ? DataTypes.VIRTUAL(DataTypes.TEXT) : DataTypes.TEXT,
    get() {
      return this.getDataValue('avatar') || '';
    },
    set(value) {
      this.setDataValue('avatar', value);
    }
  },
  createdAt: {
    type: DataTypes.DATE,
    field: 'created_at',
    defaultValue: DataTypes.NOW,
  }
}, {
  sequelize,
  tableName: 'users',
  timestamps: false,
});

// ==========================================
// 2. TRAVEL POST MODEL
// ==========================================
interface PostAttributes {
  id: string;
  author: string;
  authorAvatar?: string | null;
  timeAgo?: string | null;
  location?: string | null;
  title: string;
  description: string;
  cost?: string | null;
  duration?: string | null;
  imageUrl?: string | null;
  imageAlt?: string | null;
  votes?: number | null;
  commentsCount?: number | null;
  difficulty?: string | null;
  dayByDay?: any; // JSON
  createdAt?: Date;
}
interface PostCreationAttributes extends Optional<PostAttributes, 'votes' | 'commentsCount' | 'dayByDay' | 'createdAt'> {}

export class Post extends Model<PostAttributes, PostCreationAttributes> implements PostAttributes {
  public id!: string;
  public author!: string;
  public authorAvatar?: string | null;
  public timeAgo?: string | null;
  public location?: string | null;
  public title!: string;
  public description!: string;
  public cost?: string | null;
  public duration?: string | null;
  public imageUrl?: string | null;
  public imageAlt?: string | null;
  public votes!: number | null;
  public commentsCount!: number | null;
  public difficulty?: string | null;
  public dayByDay?: any;
  public readonly createdAt!: Date;
}

Post.init({
  id: {
    type: DataTypes.STRING,
    primaryKey: true,
  },
  author: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  authorAvatar: {
    type: DataTypes.STRING,
    field: 'author_avatar',
    allowNull: true,
  },
  timeAgo: {
    type: DataTypes.STRING,
    field: 'time_ago',
    allowNull: true,
  },
  location: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  title: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  cost: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  duration: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  imageUrl: {
    type: DataTypes.TEXT,
    field: 'image_url',
    allowNull: true,
  },
  imageAlt: {
    type: DataTypes.TEXT,
    field: 'image_alt',
    allowNull: true,
  },
  votes: {
    type: DataTypes.INTEGER,
    defaultValue: 0,
  },
  commentsCount: {
    type: DataTypes.INTEGER,
    field: 'comments_count',
    defaultValue: 0,
  },
  difficulty: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  dayByDay: {
    type: DataTypes.JSON,
    field: 'day_by_day',
    defaultValue: [],
  },
  createdAt: {
    type: DataTypes.DATE,
    field: 'created_at',
    defaultValue: DataTypes.NOW,
  }
}, {
  sequelize,
  tableName: 'posts',
  timestamps: false,
});

// ==========================================
// 3. COMMENT MODEL
// ==========================================
interface CommentAttributes {
  id: string;
  postId: string;
  parentId?: string | null;
  author: string;
  authorAvatar?: string | null;
  timeAgo?: string | null;
  votes?: number | null;
  text: string;
  isVerified?: boolean | null;
  createdAt?: Date;
}
interface CommentCreationAttributes extends Optional<CommentAttributes, 'parentId' | 'votes' | 'isVerified' | 'createdAt'> {}

export class Comment extends Model<CommentAttributes, CommentCreationAttributes> implements CommentAttributes {
  public id!: string;
  public postId!: string;
  public parentId?: string | null;
  public author!: string;
  public authorAvatar?: string | null;
  public timeAgo?: string | null;
  public votes!: number | null;
  public text!: string;
  public isVerified!: boolean | null;
  public readonly createdAt!: Date;
}

Comment.init({
  id: {
    type: DataTypes.STRING,
    primaryKey: true,
  },
  postId: {
    type: DataTypes.STRING,
    field: 'post_id',
    allowNull: false,
  },
  parentId: {
    type: DataTypes.STRING,
    field: 'parent_id',
    allowNull: true,
  },
  author: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  authorAvatar: {
    type: DataTypes.STRING,
    field: 'author_avatar',
    allowNull: true,
  },
  timeAgo: {
    type: DataTypes.STRING,
    field: 'time_ago',
    allowNull: true,
  },
  votes: {
    type: DataTypes.INTEGER,
    defaultValue: 0,
  },
  text: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  isVerified: {
    type: DataTypes.BOOLEAN,
    field: 'is_verified',
    defaultValue: false,
  },
  createdAt: {
    type: DataTypes.DATE,
    field: 'created_at',
    defaultValue: DataTypes.NOW,
  }
}, {
  sequelize,
  tableName: 'comments',
  timestamps: false,
});

// ==========================================
// 4. PACKAGE MODEL
// ==========================================
interface PackageAttributes {
  id: string;
  title: string;
  destination?: string | null;
  duration?: string | null;
  agencyName: string;
  agencyLogo?: string | null;
  isVerifiedAgency?: boolean | null;
  imageUrl?: string | null;
  imageAlt?: string | null;
  price?: number | null;
  status?: string | null;
  description?: string | null;
  inclusions?: any;
  stayNameText?: string | null;
  stayDescText?: string | null;
  stayRating?: string | null;
  stayReviewsCount?: number | null;
  stayValue?: number | null;
  dayByDay?: any;
  createdAt?: Date;
}
interface PackageCreationAttributes extends Optional<PackageAttributes, 'isVerifiedAgency' | 'price' | 'status' | 'inclusions' | 'stayRating' | 'stayReviewsCount' | 'stayValue' | 'dayByDay' | 'createdAt'> {}

export class Package extends Model<PackageAttributes, PackageCreationAttributes> implements PackageAttributes {
  public id!: string;
  public title!: string;
  public destination?: string | null;
  public duration?: string | null;
  public agencyName!: string;
  public agencyLogo?: string | null;
  public isVerifiedAgency!: boolean | null;
  public imageUrl?: string | null;
  public imageAlt?: string | null;
  public price!: number | null;
  public status!: string | null;
  public description?: string | null;
  public inclusions?: any;
  public stayNameText?: string | null;
  public stayDescText?: string | null;
  public stayRating?: string | null;
  public stayReviewsCount!: number | null;
  public stayValue!: number | null;
  public dayByDay?: any;
  public readonly createdAt!: Date;
}

Package.init({
  id: {
    type: DataTypes.STRING,
    primaryKey: true,
  },
  title: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  destination: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  duration: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  agencyName: {
    type: DataTypes.STRING,
    field: 'agency_name',
    allowNull: false,
  },
  agencyLogo: {
    type: DataTypes.TEXT,
    field: 'agency_logo',
    allowNull: true,
  },
  isVerifiedAgency: {
    type: DataTypes.BOOLEAN,
    field: 'is_verified_agency',
    defaultValue: false,
  },
  imageUrl: {
    type: DataTypes.TEXT,
    field: 'image_url',
    allowNull: true,
  },
  imageAlt: {
    type: DataTypes.TEXT,
    field: 'image_alt',
    allowNull: true,
  },
  price: {
    type: DataTypes.INTEGER,
    defaultValue: 0,
  },
  status: {
    type: DataTypes.STRING,
    defaultValue: 'Active',
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  inclusions: {
    type: DataTypes.JSON,
    defaultValue: [],
  },
  stayNameText: {
    type: DataTypes.STRING,
    field: 'stay_name_text',
    allowNull: true,
  },
  stayDescText: {
    type: DataTypes.TEXT,
    field: 'stay_desc_text',
    allowNull: true,
  },
  stayRating: {
    type: DataTypes.STRING,
    field: 'stay_rating',
    defaultValue: '4.5',
  },
  stayReviewsCount: {
    type: DataTypes.INTEGER,
    field: 'stay_reviews_count',
    defaultValue: 0,
  },
  stayValue: {
    type: DataTypes.INTEGER,
    field: 'stay_value',
    defaultValue: 0,
  },
  dayByDay: {
    type: DataTypes.JSON,
    field: 'day_by_day',
    defaultValue: [],
  },
  createdAt: {
    type: DataTypes.DATE,
    field: 'created_at',
    defaultValue: DataTypes.NOW,
  }
}, {
  sequelize,
  tableName: 'packages',
  timestamps: false,
});

// ==========================================
// 5. AGENCY VERIFICATION QUEUE MODEL
// ==========================================
interface VerificationAttributes {
  id: string;
  companyName: string;
  submittedAt?: string | null;
  email?: string | null;
  phone?: string | null;
  filesCount?: number | null;
  text?: string | null;
  status?: string | null;
  createdAt?: Date;
}
interface VerificationCreationAttributes extends Optional<VerificationAttributes, 'filesCount' | 'status' | 'createdAt'> {}

export class Verification extends Model<VerificationAttributes, VerificationCreationAttributes> implements VerificationAttributes {
  public id!: string;
  public companyName!: string;
  public submittedAt?: string | null;
  public email?: string | null;
  public phone?: string | null;
  public filesCount!: number | null;
  public status!: string | null;
  public readonly createdAt!: Date;
}

Verification.init({
  id: {
    type: DataTypes.STRING,
    primaryKey: true,
  },
  companyName: {
    type: DataTypes.STRING,
    field: 'company_name',
    allowNull: false,
  },
  submittedAt: {
    type: DataTypes.STRING,
    field: 'submitted_at',
    allowNull: true,
  },
  email: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  phone: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  filesCount: {
    type: DataTypes.INTEGER,
    field: 'files_count',
    defaultValue: 0,
  },
  status: {
    type: DataTypes.STRING,
    defaultValue: 'pending',
  },
  createdAt: {
    type: DataTypes.DATE,
    field: 'created_at',
    defaultValue: DataTypes.NOW,
  }
}, {
  sequelize,
  tableName: 'verifications',
  timestamps: false,
});

// ==========================================
// 6. FLAGGED POSTS / SPAM MODEL
// ==========================================
interface FlaggedPostAttributes {
  id: string;
  username: string;
  userAvatar?: string | null;
  timeAgo?: string | null;
  type?: string | null;
  content?: string | null;
  createdAt?: Date;
}
interface FlaggedPostCreationAttributes extends Optional<FlaggedPostAttributes, 'createdAt'> {}

export class FlaggedPost extends Model<FlaggedPostAttributes, FlaggedPostCreationAttributes> implements FlaggedPostAttributes {
  public id!: string;
  public username!: string;
  public userAvatar?: string | null;
  public timeAgo?: string | null;
  public type?: string | null;
  public content?: string | null;
  public readonly createdAt!: Date;
}

FlaggedPost.init({
  id: {
    type: DataTypes.STRING,
    primaryKey: true,
  },
  username: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  userAvatar: {
    type: DataTypes.STRING,
    field: 'user_avatar',
    allowNull: true,
  },
  timeAgo: {
    type: DataTypes.STRING,
    field: 'time_ago',
    allowNull: true,
  },
  type: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  content: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  createdAt: {
    type: DataTypes.DATE,
    field: 'created_at',
    defaultValue: DataTypes.NOW,
  }
}, {
  sequelize,
  tableName: 'flagged_posts',
  timestamps: false,
});

// ==========================================
// 7. COMMENT REPORT MODEL
// ==========================================
interface CommentReportAttributes {
  id: string;
  username: string;
  postId?: string | null;
  postTitle?: string | null;
  text: string;
  reportsCount?: number | null;
  createdAt?: Date;
}
interface CommentReportCreationAttributes extends Optional<CommentReportAttributes, 'reportsCount' | 'createdAt'> {}

export class CommentReport extends Model<CommentReportAttributes, CommentReportCreationAttributes> implements CommentReportAttributes {
  public id!: string;
  public username!: string;
  public postId?: string | null;
  public postTitle?: string | null;
  public text!: string;
  public reportsCount!: number | null;
  public readonly createdAt!: Date;
}

CommentReport.init({
  id: {
    type: DataTypes.STRING,
    primaryKey: true,
  },
  username: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  postId: {
    type: DataTypes.STRING,
    field: 'post_id',
    allowNull: true,
  },
  postTitle: {
    type: DataTypes.STRING,
    field: 'post_title',
    allowNull: true,
  },
  text: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  reportsCount: {
    type: DataTypes.INTEGER,
    field: 'reports_count',
    defaultValue: 1,
  },
  createdAt: {
    type: DataTypes.DATE,
    field: 'created_at',
    defaultValue: DataTypes.NOW,
  }
}, {
  sequelize,
  tableName: 'comment_reports',
  timestamps: false,
});

// ==========================================
// 8. AUDIT LOGS MODEL
// ==========================================
interface AuditLogAttributes {
  id: number;
  entityType: string;
  entityId: string;
  action: string;
  performedBy: string;
  details?: string | null;
  timestamp?: Date;
}
interface AuditLogCreationAttributes extends Optional<AuditLogAttributes, 'id' | 'timestamp'> {}

export class AuditLog extends Model<AuditLogAttributes, AuditLogCreationAttributes> implements AuditLogAttributes {
  public id!: number;
  public entityType!: string;
  public entityId!: string;
  public action!: string;
  public performedBy!: string;
  public details?: string | null;
  public readonly timestamp!: Date;
}

AuditLog.init({
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  entityType: {
    type: DataTypes.STRING,
    field: 'entity_type',
    allowNull: false,
  },
  entityId: {
    type: DataTypes.STRING,
    field: 'entity_id',
    allowNull: false,
  },
  action: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  performedBy: {
    type: DataTypes.STRING,
    field: 'performed_by',
    allowNull: false,
  },
  details: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  timestamp: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  }
}, {
  sequelize,
  tableName: 'audit_logs',
  timestamps: false,
});
