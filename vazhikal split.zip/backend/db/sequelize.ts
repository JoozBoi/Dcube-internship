import { Sequelize } from 'sequelize';
import dotenv from 'dotenv';

dotenv.config();

const dbHost = process.env.SQL_HOST || 'localhost';
const dbPort = parseInt(process.env.SQL_PORT || '5432', 10);
const dbName = process.env.SQL_DB_NAME || 'vazhikal_db';
const dbUser = process.env.SQL_USER || 'vazhikal_admin';
const dbPassword = process.env.SQL_PASSWORD || 'SecurePassword123';

export const sequelize = new Sequelize(dbName, dbUser, dbPassword, {
  host: dbHost,
  port: dbPort,
  dialect: 'postgres',
  logging: process.env.NODE_ENV === 'development' ? console.log : false,
  pool: {
    max: 10,
    min: 0,
    acquire: 30000,
    idle: 10000
  },
  define: {
    timestamps: true
  }
});

export const connectSequelize = async () => {
  try {
    await sequelize.authenticate();
    console.log('✓ Sequelize successfully completed Postgres handshake.');
  } catch (err) {
    console.error('✗ Sequelize was unable to connect to the database:', err);
  }
};
