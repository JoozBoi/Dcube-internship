import { Request, Response, NextFunction } from 'express';

export interface UserContext {
  role: string;
  name: string;
  username: string;
}

// Module augmentation to extend Express Request interface with type-safe userContext
declare global {
  namespace Express {
    interface Request {
      userContext?: UserContext;
    }
  }
}

/**
 * Middleware that extracts user context information from custom requests headers
 * and populates req.userContext for downstream endpoint routes.
 */
export function userContextMiddleware(req: Request, res: Response, next: NextFunction) {
  const role = (req.headers['x-user-role'] as string) || 'traveller';
  const username = (req.headers['x-user-username'] as string) || 
    (role === 'admin' ? 'admin' : role === 'agency' ? 'EverestTrek' : 'SaraWanderer');
  
  req.userContext = {
    role,
    name: username,
    username
  };
  
  next();
}
