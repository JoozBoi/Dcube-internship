import { Request, Response, NextFunction } from 'express';

/**
 * Custom request logger that outputs professional logs to track
 * execution times, endpoints, codes, and calling user contexts.
 */
export function requestLogger(req: Request, res: Response, next: NextFunction) {
  const start = Date.now();
  const { method, originalUrl } = req;
  
  res.on('finish', () => {
    const duration = Date.now() - start;
    const statusCode = res.statusCode;
    const actor = req.userContext?.name || 'Anonymous';
    const role = req.userContext?.role || 'Guest';
    
    console.log(
      `[API-LOG] ${method} ${originalUrl} - Status: ${statusCode} - Performed by: ${actor} (${role}) - ${duration}ms`
    );
  });
  
  next();
}
