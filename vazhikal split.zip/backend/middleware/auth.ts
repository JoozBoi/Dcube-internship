import { Request, Response, NextFunction } from 'express';

/**
 * Higher-order middleware factory to restrict access to specific roles.
 */
export function restrictTo(...allowedRoles: string[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    const userRole = req.userContext?.role || 'traveller';
    
    if (!allowedRoles.includes(userRole)) {
      return res.status(403).json({
        error: `Permission denied: access is restricted to [${allowedRoles.join(', ')}] roles only (your role matches '${userRole}').`
      });
    }
    
    next();
  };
}

/**
 * Pre-configured middleware helper to restrict access to administrators only.
 */
export const requireAdmin = restrictTo('admin');

/**
 * Pre-configured middleware helper to restrict access to registered agency partners or admins.
 */
export const requireAgency = restrictTo('agency', 'admin');
