import { Request, Response, NextFunction } from 'express';

/**
 * Standard centralized error handling middleware to gracefully handle exceptions
 * and respond with structured, secure JSON payloads to the frontend.
 */
export function globalErrorHandler(err: any, req: Request, res: Response, next: NextFunction) {
  console.error('[GLOBAL-ERROR-HANDLER] Uncaught exception occurred:', err);
  
  const status = err.statusCode || err.status || 500;
  const message = err.message || 'An unexpected server error occurred inside Vazhikal Trails service.';
  
  res.status(status).json({
    error: message,
    timestamp: new Date().toISOString(),
    path: req.originalUrl,
    stack: process.env.NODE_ENV === 'development' ? err.stack : undefined
  });
}
