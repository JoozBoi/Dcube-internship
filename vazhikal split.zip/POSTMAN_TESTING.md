# Vazhikal Trails - Postman API Testing Guide 📮🚀

This guide explains step-by-step how to export, configure, and thoroughly test every API endpoint in **Vazhikal Trails** using Postman on your local computer.

Since the application uses custom metadata headers to handle user roles and profile names dynamically, you will learn how to simulate **Traveller**, **Agency**, and **Admin** environments with zero complex backend logins!

---

## 💾 Step 1: Export Project as ZIP from AI Studio

To run this on your laptop, you need to download the source files.
1. Look at the upper-right corner of the **Google AI Studio** workspace.
2. Click the ⚙️ **Settings** gear icon (or the project dropdown menu near the name).
3. Find and click **"Export as ZIP"** (or **"Export to GitHub"**).
4. Extract the `.zip` file into a directory on your local machine (e.g., `Documents/vazhikal-trails`).

---

## ⚡ Step 2: Ensure Local Database and Dev Server are Running

Before opening Postman, make sure your PostgreSQL database is operational and your Node.js application is listening on port `3000`:
1. Open your terminal or Command Prompt inside the project folder.
2. Confirm `.env` has correct database details matching your local PostgreSQL:
   ```env
   PORT=3000
   SQL_HOST=localhost
   SQL_PORT=5432
   SQL_DB_NAME=vazhikal_db
   SQL_USER=postgres
   SQL_PASSWORD=your_real_password
   ```
3. Run:
   ```bash
   npm install
   npm run dev
   ```
4. Look for the console message indicating successfully established database handshakes and starting server on `http://localhost:3000`.

---

## 📋 Step 3: Understanding the Context Headers in Postman

We use a custom, robust **User Context Middleware** (`/backend/middleware/context.ts`) to manage roles and identities locally. In Postman, to act as a specific user, you must always navigate to the **Headers** tab of your requests and add the following two rows:

| Header Key | Header Value (Traveller) | Header Value (Agency) | Header Value (Admin) |
| :--- | :--- | :--- | :--- |
| `x-user-role` | `traveller` | `agency` | `admin` |
| `x-user-username` | `SaraWanderer` | `EverestTrek` | `admin` |

*If you do not specify these headers, the server automatically defaults to role `traveller` and username `SaraWanderer`.*

---

## 🗺️ Step 4: Testing Every Endpoint Step-By-Step

Open Postman, create a new Workspace, and begin testing the following routes:

### 1. User Management

#### A. Fetch All Registered Users
* **Method**: `GET`
* **URL**: `http://localhost:3000/api/users`
* **Headers**: 
  - `Content-Type`: `application/json`
* **Expected Response**: Status `200 OK` containing a list of all seed users.

#### B. Register a New User
* **Method**: `POST`
* **URL**: `http://localhost:3000/api/users`
* **Headers**:
  - `Content-Type`: `application/json`
* **Body (Raw JSON)**:
  ```json
  {
    "username": "NomadAlex",
    "email": "alex@nomad.com",
    "password": "securepwd123",
    "role": "traveller",
    "bio": "Backpacker exploring coastal shortcuts."
  }
  ```
* **Expected Response**: Status `201 Created` with the newly saved user record.

#### C. Synchronize/Update Profile Coordinates
* **Method**: `PUT`
* **URL**: `http://localhost:3000/api/users/alex@nomad.com`
* **Headers**:
  - `Content-Type`: `application/json`
  - `x-user-role`: `traveller`
  - `x-user-username`: `NomadAlex`
* **Body (Raw JSON)**:
  ```json
  {
    "username": "AlexTheExplorer",
    "bio": "Updated bio - scaling the Himalayas this summer!",
    "email": "alex@nomad.com"
  }
  ```
* **Expected Response**: Status `200 OK` showing updated user details.

---

### 2. Experiential Trails (Trail Posts)

#### A. Fetch All Trails / Handcrafted Itineraries
* **Method**: `GET`
* **URL**: `http://localhost:3000/api/posts`
* **Headers**: None required (public action)
* **Expected Response**: Status `200 OK` listing available posts with their complete, nested comment trees.

#### B. Publish a New Experiential Trail (Add Post)
* **Method**: `POST`
* **URL**: `http://localhost:3000/api/posts`
* **Headers**:
  - `Content-Type`: `application/json`
  - `x-user-role`: `traveller`
  - `x-user-username`: `AlexTheExplorer`
* **Body (Raw JSON)**:
  ```json
  {
    "title": "Annapurna Sanctuary Expedition",
    "location": "Nepal",
    "description": "A magnificent teahouse trek through high mountain valleys.",
    "cost": "$250 USD",
    "duration": "5 Days",
    "difficulty": "Challenging",
    "imageUrl": "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=800",
    "imageAlt": "Annapurna Base Camp",
    "dayByDay": [
      {
        "day": 1,
        "title": "Jeep to Jhinu Danda & ascend to Chhomrong",
        "description": "Steep stone staircase walking through rhododendron woods.",
        "badges": ["Ascent", "Suspension Bridge"]
      }
    ]
  }
  ```
* **Expected Response**: Status `201 Created` with a unique `id` generated for the new itinerary node (record this `id` for subsequent tests, e.g., `id: 5`).

#### C. Cast Vote on a Trail (+1 Upvote or -1 Downvote)
* **Method**: `POST`
* **URL**: `http://localhost:3000/api/api/posts/5/vote` *(Replace 5 with your generated post ID)*
* **Headers**:
  - `Content-Type`: `application/json`
  - `x-user-role`: `traveller`
  - `x-user-username`: `SaraWanderer`
* **Body (Raw JSON)**:
  ```json
  {
    "amount": 1
  }
  ```
* **Expected Response**: Status `200 OK` returning the newly aggregated vote tally, e.g., `"votes": 1`.

#### D. Delete an Experiential Trail
* **Method**: `DELETE`
* **URL**: `http://localhost:3000/api/posts/5` *(Replace 5 with your post ID)*
* **Headers**:
  - `x-user-role`: `traveller`
  - `x-user-username`: `AlexTheExplorer` *(Must match the author of the post, or be the admin!)*
* **Expected Response**: Status `200 OK` indicating successful purge.

---

### 3. Nested Collaborative Discussions (Comments)

#### A. Post a Comment or a Nested Reply
* **Method**: `POST`
* **URL**: `http://localhost:3000/api/posts/2/comments` *(Replace 2 with your target post ID)*
* **Headers**:
  - `Content-Type`: `application/json`
  - `x-user-role`: `traveller`
  - `x-user-username`: `SaraWanderer`
* **Body (Raw JSON)**:
  ```json
  {
    "text": "Is this trek safe to perform solo during monsoon season?",
    "parentId": null
  }
  ```
  *(To write a **nested reply**, change `"parentId"` from `null` to the `id` of an existing comment response!)*
* **Expected Response**: Status `201 Created` showing comment structure placed recursively inside the database.

#### B. Purge Comment Node recursively
* **Method**: `DELETE`
* **URL**: `http://localhost:3000/api/comments/12` *(Replace 12 with your comment ID)*
* **Headers**:
  - `x-user-role`: `traveller`
  - `x-user-username`: `SaraWanderer` *(Or `admin`)*
* **Expected Response**: Status `200 OK` describing full removal of the target node and any nested sub-branches.

---

### 4. Certified Tour Agencies & Packages

#### A. Request Agency Verification 
* **Method**: `POST`
* **URL**: `http://localhost:3000/api/verifications`
* **Headers**:
  - `Content-Type`: `application/json`
  - `x-user-role`: `traveller`
  - `x-user-username`: `EverestTrek`
* **Body (Raw JSON)**:
  ```json
  {
    "companyName": "Everest Trek Partners",
    "email": "contact@everesttrek.np",
    "phone": "+977-1-443213",
    "filesCount": 2
  }
  ```
* **Expected Response**: Status `201 Created` stating the verification application has been submitted to the queue. (Take note of the returned verification application `id`, e.g., `id: 3`).

#### B. Approve Verification & Grant Agency Role (*Admin Restricted*)
* **Method**: `POST`
* **URL**: `http://localhost:3000/api/verifications/3/approve` *(Replace 3 with your application ID)*
* **Headers**:
  - `x-user-role`: `admin`
  - `x-user-username`: `admin`
* **Expected Response**: Status `200 OK`. The system upgrades the original applicant's role from `'traveller'` to `'agency'`, logging the event coordinates.

#### C. Create Curated Tour Package (*Agency Only*)
* **Method**: `POST`
* **URL**: `http://localhost:3000/api/packages`
* **Headers**:
  - `Content-Type`: `application/json`
  - `x-user-role`: `agency`
  - `x-user-username`: `EverestTrek`
* **Body (Raw JSON)**:
  ```json
  {
    "title": "Luxury Everest Views Panorama",
    "destination": "Solukhumbu, Nepal",
    "duration": "4 Days, 3 Nights",
    "price": 1850,
    "description": "Exclusive flight tours and premium boutique stays.",
    "inclusions": ["Helicopter Tour", "Stay at Yeti Mountain Home", "All organic meals"],
    "stayNameText": "Yeti Mountain Home residency",
    "stayDescText": "Custom high-altitude luxury cabins with heated blankets.",
    "stayValue": 750
  }
  ```
* **Expected Response**: Status `201 Created` with your registered commercial package.

---

### 5. Administrative Controls, Flags & Audit Logs

#### A. Fetch System Audit Logs (*Admin Restricted*)
* **Method**: `GET`
* **URL**: `http://localhost:3000/api/admin/audit-logs`
* **Headers**:
  - `x-user-role`: `admin`
  - `x-user-username`: `admin`
* **Expected Response**: Status `200 OK` displaying system coordinates.
* **Security Check**: Attempt making this call **without** the `admin` headers (e.g. `x-user-role: traveller`). Postman will immediately return `403 Forbidden` courtesy of the new `requireAdmin` middleware checking!

#### B. Flag a Post for Admin Review
* **Method**: `POST`
* **URL**: `http://localhost:3000/api/flagged-posts`
* **Headers**:
  - `Content-Type`: `application/json`
  - `x-user-role`: `traveller`
  - `x-user-username`: `SaraWanderer`
* **Body (Raw JSON)**:
  ```json
  {
    "postId": 1,
    "reason": "This trail description details dangerous pathways."
  }
  ```
* **Expected Response**: Status `201 Created`.

#### C. Retrieve All Flagged Posts Queue (*Admin Restricted*)
* **Method**: `GET`
* **URL**: `http://localhost:3000/api/flagged-posts`
* **Headers**:
  - `x-user-role`: `admin`
  - `x-user-username`: `admin`
* **Expected Response**: Status `200 OK`.

#### D. Dismiss Flag / Resolve Post Review Queue (*Admin Restricted*)
* **Method**: `DELETE`
* **URL**: `http://localhost:3000/api/flagged-posts/1` *(Replace 1 with the flagged post entry ID)*
* **Headers**:
  - `x-user-role`: `admin`
  - `x-user-username`: `admin`
* **Expected Response**: Status `200 OK` showing successful resolution.

---

## 💡 Pro-Tip: Creating a Postman Environment Context

To avoid manual typing on every header for each request:
1. In Postman, click on **Environments** (left-sidebar).
2. Create an Environment called **`Vazhikal - Traveller`**, and add:
   - `role` ➡️ `traveller`
   - `username` ➡️ `SaraWanderer`
3. Create another called **`Vazhikal - Admin`**, and add:
   - `role` ➡️ `admin`
   - `username` ➡️ `admin`
4. In your request headers, set the key `x-user-role` to `{{role}}` and `x-user-username` to `{{username}}`.
5. Switch environments from the upper right dropdown to instantly shift context roles inside your testing workflows!

Happy integration testing! 🏔️✈️
