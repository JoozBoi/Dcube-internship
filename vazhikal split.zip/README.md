# Vazhikal Trails - Local Setup and Execution Guide 🏔️✈️

Welcome to **Vazhikal Trails**, a collaborative social travel platform, experiential itinerary sharing ecosystem, and certified tour agency marketplace. The application operates on a full-stack architecture powered by:
- **Frontend**: React (Vite) styled with Tailwind CSS
- **Backend**: Node.js & Express API server 
- **Database**: PostgreSQL mapped securely via the Sequelize ORM

This guide is designed specifically for **absolute beginners**. Follow these simple steps one-by-one to get the entire platform up and running on your local computer!

---

## 📂 Project Architecture Overview

This is how the files are structured in your project:
- `/backend/server.ts` — The main entry point that boots the Express API server, manages routes, and serves the static React frontend resources.
- `/backend/middleware/` — **Industry-Grade Middlewares** separating logic for secure, scalable api requests:
  - `context.ts` — Evaluates inbound headers (`x-user-role`, `x-user-username`) and maps them straight to the request context object.
  - `auth.ts` — Protects administrative or agency-only endpoints with role-based restrictions.
  - `requestLogger.ts` — Outputs custom backend logs to track API durations, HTTP codes, and performance stats.
  - `errorHandler.ts` — Captures all server exceptions centrally, sending uniform, secure error codes to the client.
  - `index.ts` — Consolidates and exports all middlewares cleanly.
- `/backend/db/sequelize.ts` — Manages the connection pool and handshake coordinates to PostgreSQL.
- `/backend/db/models.ts` — Maps the 8 database tables: `User`, `Post`, `Comment`, `Package`, `Verification`, `FlaggedPost`, `CommentReport`, and `AuditLog`.
- `/frontend/` — The interactive user interface code built with structured, animated React components and Lucide icons.
- `setup_db.py` — A powerful database automation script that guarantees zero SQL syntax frustration.

---

## 🛠️ Step 1: Install PostgreSQL database on your computer

PostgreSQL is the database engine that stores your user accounts, travel itineraries, and discussion logs.

### On Windows or macOS:
1. **Download the Installer**: Go to the [Official PostgreSQL Downloads Page](https://www.postgresql.org/download/) and select **Windows** or **macOS**. Download the installer by EnterpriseDB.
2. **Run the Installer**: Leave all components checked:
   - ✅ **PostgreSQL Server** (The engine)
   - ✅ **pgAdmin 4** (A desktop program with a visual interface to see your database)
   - ✅ **Command Line Tools** (Required helper utilities)
3. **Choose a Password**: 
   - During setup, the installer will ask you to set a password for the default database administrator (user named `postgres`). 
   - Write this password down! (For simple local setups, we recommend using `password` so it matches the defaults automatically).
4. **Port Configuration**: Leave the port number at its standard default **`5432`**. Keep clicking "Next" to finish the wizard.

---

## 📝 Step 2: Configure Your Connection Coordinates

The application reads database configuration credentials from a file in the project's root folder called `.env`.

1. Check if a database credentials file named `.env` already exists in the project root folder.
2. If it does not exist, create a new text file named `.env` in the root folder.
3. Paste the following configuration inside the `.env` file:

```env
# Server Customization Ports
PORT=3000
NODE_ENV=development

# SQL Database Credentials (configured from setup_db.py)
SQL_HOST=localhost
SQL_PORT=5432
SQL_DB_NAME=vazhikal_db
SQL_USER=postgres
SQL_PASSWORD=password

# Optional Gemini AI Secret Key (Only required if using AI features)
GEMINI_API_KEY=""
```

> **Beginner Tip:** If you chose a password other than `password` when installing PostgreSQL in Step 1, make sure to replace `SQL_PASSWORD=password` with your real PostgreSQL password in this file!

---

## 🐍 Step 3: Run the Database Automator (Zero SQL Frustration)

We created a custom Python script (`setup_db.py`) that handles the hard work of creating the database database (`vazhikal_db`) and preparing the necessary tables.

1. Open your terminal (macOS/Linux) or Command Prompt (Windows).
2. Use the `cd` command to navigate to the folder where you extracted this project:
   ```bash
   cd /path/to/vazhikal-trails
   ```
3. Run the database setup script:
   ```bash
   python setup_db.py
   ```
4. **That's it!** The command will check if Python has database connectors, install them if missing, establish a connection, build the database, and define all database schemas.

*Note: If you do not have Python installed, you can skip this step and start the application directly in Step 5 inside your terminal. The Express backend uses Sequelize, which is designed to automatically establish schemas upon booting when it connects to your local PostgreSQL server database! Just make sure to first open pgAdmin 4 and create a new empty database named `vazhikal_db`.*

---

## 🔍 Step 4: Examine Your Database with pgAdmin 4

Want to see what's happening behind the scenes? You can visually examine the tables with your PostgreSQL viewer:

1. Open **pgAdmin 4** on your computer.
2. Expand the **Servers** menu in the left pane. Double-click to expand, entering the administrator password you set during installation.
3. Expand **Databases** ➡️ You will see the newly generated **`vazhikal_db`** database!
4. Navigate deeper through:
   `vazhikal_db` ➡️ `Schemas` ➡️ `public` ➡️ `Tables`
5. Here, you will see your tables fully synchronized:
   - `users` — Stores registered accounts, passwords, and bios.
   - `posts` — Experiential trails posted by travelers.
   - `comments` — Fully-nested, collaborative discussion threads.
   - `packages` — Premium agency packages.
   - `audit_logs` — System administration events.
6. **Want to view your records?** Right-click any table ➡️ Hover over **View/Edit Data** ➡️ Click **All Rows**. The data records grid will instantly appear!

---

## 🚀 Step 5: Start the Application (Express Server + React)

Now, we will download the required Node.js package dependencies and boot the application!

1. Open your terminal or command prompt inside the project folder.
2. Run the command to install all necessary code packages on your machine:
   ```bash
   npm install
   ```
3. Start the dynamic full-stack development environment:
   ```bash
   npm run dev
   ```
4. The system launches the Express backend API and the Vite frontend concurrently. Open your favorite web browser and navigate to:
   ```
   http://localhost:3000
   ```
5. **Congratulations!** Your local social travel platform is live! The server will also automatically seed your database tables with travel itineraries on your very first boot!

---

## 🛠️ Troubleshooting Step-by-Step

### 1. Error: `"tsx" is not recognized as an internal or external command`
* **Root Cause**: This means the dependencies aren't installed on your computer yet.
* **Fix**: Ensure you ran `npm install` inside the project folder. If it failed, delete the `node_modules` folder and retry `npm install`.

### 2. Error: `Could not connect to default postgres database`
* **Root Cause**: PostgreSQL isn't running on your computer, or your username/password in `.env` is incorrect.
* **Fix**:
  1. Open pgAdmin 4 to verify that the PostgreSQL database engine is active.
  2. Open `.env` and verify that `SQL_USER=postgres` and `SQL_PASSWORD` matches the administrative credentials you set during installation.

### 3. Error: `Address already in use :::3000`
* **Root Cause**: Another application is currently running on port `3000`.
* **Fix**: Close any other command prompt running on your host, or change `PORT=3000` in `.env` to another number (e.g., `PORT=3080`) and connect to `http://localhost:3080`.

---

Enjoy charting beautiful trails on your local full-stack workspace! 🗺️✨
